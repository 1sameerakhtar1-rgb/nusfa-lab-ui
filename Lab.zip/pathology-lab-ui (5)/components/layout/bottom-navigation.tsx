'use client'

import { 
  Home, 
  TestTube2, 
  FileText, 
  Receipt, 
  BarChart3, 
  MoreHorizontal,
  Plus
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'

interface BottomNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
  onNewSample: () => void
}

const navItems = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'samples', label: 'Samples', icon: TestTube2 },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'billing', label: 'Billing', icon: Receipt },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'more', label: 'More', icon: MoreHorizontal },
]

export function BottomNavigation({ activeTab, onTabChange, onNewSample }: BottomNavigationProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Floating Action Button */}
      <div className="absolute -top-7 left-1/2 -translate-x-1/2 z-10">
        <Button
          onClick={onNewSample}
          className="h-14 w-14 rounded-full bg-primary shadow-lg shadow-primary/30 hover:bg-primary/90 hover:shadow-xl hover:shadow-primary/40 transition-all duration-300"
          size="icon"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>
      
      {/* Navigation Bar */}
      <div className="bg-card/95 backdrop-blur-xl border-t border-border/50 px-2 pb-safe">
        <nav className="flex items-center justify-around py-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = activeTab === item.id
            
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all duration-200 min-w-[60px]",
                  isActive 
                    ? "text-primary bg-primary/10" 
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
              >
                <Icon className={cn(
                  "h-5 w-5 transition-transform duration-200",
                  isActive && "scale-110"
                )} />
                <span className={cn(
                  "text-[10px] font-medium",
                  isActive && "font-semibold"
                )}>
                  {item.label}
                </span>
                {isActive && (
                  <div className="absolute bottom-1 w-1 h-1 rounded-full bg-primary" />
                )}
              </button>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
