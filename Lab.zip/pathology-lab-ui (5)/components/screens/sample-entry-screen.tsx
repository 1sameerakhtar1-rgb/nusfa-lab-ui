'use client'

import { useState, useEffect } from 'react'
import { 
  ArrowLeft, 
  Barcode, 
  QrCode, 
  Calendar,
  Phone,
  Mail,
  MapPin,
  User,
  Search,
  Plus,
  Minus,
  Truck,
  AlertTriangle,
  IndianRupee,
  Percent,
  CreditCard,
  Check,
  X
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { mockTests, mockDoctors, testCategories } from '@/lib/mock-data'
import { PatientTitle, Gender, PaymentMethod, Priority } from '@/lib/types'
import { cn } from '@/lib/utils'

interface SampleEntryScreenProps {
  onBack: () => void
  onSubmit: (data: SampleFormData) => void
}

interface SampleFormData {
  title: PatientTitle
  name: string
  gender: Gender
  age: string
  dob: string
  phone: string
  email: string
  address: string
  city: string
  pinCode: string
  uhid: string
  doctorId: string
  selectedTests: string[]
  priority: Priority
  isHomeCollection: boolean
  isEmergency: boolean
  discount: number
  couponCode: string
  paymentMethod: PaymentMethod
  paidAmount: number
}

const titleOptions: PatientTitle[] = ['Mr.', 'Mrs.', 'Ms.', 'Md.', 'Baby', 'Master']

const titleToGender: Record<PatientTitle, Gender> = {
  'Mr.': 'Male',
  'Mrs.': 'Female',
  'Ms.': 'Female',
  'Md.': 'Male',
  'Baby': 'Other',
  'Master': 'Male',
}

const paymentMethods: PaymentMethod[] = ['Cash', 'Card', 'UPI', 'Net Banking', 'Cheque']

export function SampleEntryScreen({ onBack, onSubmit }: SampleEntryScreenProps) {
  const [formData, setFormData] = useState<SampleFormData>({
    title: 'Mr.',
    name: '',
    gender: 'Male',
    age: '',
    dob: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    pinCode: '',
    uhid: `UHID${Date.now().toString().slice(-8)}`,
    doctorId: '',
    selectedTests: [],
    priority: 'Normal',
    isHomeCollection: false,
    isEmergency: false,
    discount: 0,
    couponCode: '',
    paymentMethod: 'Cash',
    paidAmount: 0,
  })

  const [testSearch, setTestSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [showTestPicker, setShowTestPicker] = useState(false)

  // Auto-set gender based on title
  useEffect(() => {
    setFormData((prev) => ({
      ...prev,
      gender: titleToGender[prev.title],
    }))
  }, [formData.title])

  // Calculate totals
  const selectedTestDetails = mockTests.filter((t) => formData.selectedTests.includes(t.id))
  const subtotal = selectedTestDetails.reduce((sum, t) => sum + t.price, 0)
  const discountAmount = (subtotal * formData.discount) / 100
  const total = subtotal - discountAmount
  const dueAmount = total - formData.paidAmount

  const filteredTests = mockTests.filter((test) => {
    const matchesSearch = test.name.toLowerCase().includes(testSearch.toLowerCase()) ||
                         test.code.toLowerCase().includes(testSearch.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || test.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleSubmit = () => {
    onSubmit(formData)
  }

  return (
    <div className="min-h-screen pb-24 animate-fade-in">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card/95 backdrop-blur-xl border-b border-border/50 px-4 py-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={onBack} className="h-9 w-9 rounded-xl">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-base font-semibold">New Sample Entry</h1>
            <p className="text-xs text-muted-foreground">Register new patient sample</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* UHID & Barcode Section */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <Label className="text-xs text-muted-foreground">Auto Generated UHID</Label>
              <p className="text-lg font-bold text-primary font-mono">{formData.uhid}</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="rounded-xl h-9 gap-2">
                <Barcode className="h-4 w-4" />
                Print
              </Button>
              <Button variant="outline" size="sm" className="rounded-xl h-9 gap-2">
                <QrCode className="h-4 w-4" />
                QR
              </Button>
            </div>
          </div>
        </div>

        {/* Patient Details */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <User className="h-4 w-4 text-primary" />
            Patient Details
          </h3>

          {/* Title & Name Row */}
          <div className="flex gap-3">
            <div className="w-24">
              <Label className="text-xs text-muted-foreground">Title</Label>
              <Select
                value={formData.title}
                onValueChange={(value: PatientTitle) => setFormData({ ...formData, title: value })}
              >
                <SelectTrigger className="rounded-xl mt-1.5 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {titleOptions.map((title) => (
                    <SelectItem key={title} value={title}>{title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <Label className="text-xs text-muted-foreground">Patient Name</Label>
              <Input
                placeholder="Enter full name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
          </div>

          {/* Gender & Age Row */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground">Gender</Label>
              <Select
                value={formData.gender}
                onValueChange={(value: Gender) => setFormData({ ...formData, gender: value })}
              >
                <SelectTrigger className="rounded-xl mt-1.5 h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Age</Label>
              <Input
                type="number"
                placeholder="Age"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">DOB</Label>
              <div className="relative mt-1.5">
                <Input
                  type="date"
                  value={formData.dob}
                  onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                  className="rounded-xl h-10"
                />
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <Phone className="h-3 w-3" /> Phone
              </Label>
              <Input
                type="tel"
                placeholder="+91 XXXXX XXXXX"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <Mail className="h-3 w-3" /> Email
              </Label>
              <Input
                type="email"
                placeholder="email@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
          </div>

          {/* Address */}
          <div>
            <Label className="text-xs text-muted-foreground flex items-center gap-1">
              <MapPin className="h-3 w-3" /> Address
            </Label>
            <Input
              placeholder="Street address"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="rounded-xl mt-1.5 h-10"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground">City</Label>
              <Input
                placeholder="City"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">PIN Code</Label>
              <Input
                type="number"
                placeholder="PIN Code"
                value={formData.pinCode}
                onChange={(e) => setFormData({ ...formData, pinCode: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
          </div>
        </div>

        {/* Referral Doctor */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Referral Doctor</h3>
          <Select
            value={formData.doctorId}
            onValueChange={(value) => setFormData({ ...formData, doctorId: value })}
          >
            <SelectTrigger className="rounded-xl h-10">
              <SelectValue placeholder="Select referral doctor" />
            </SelectTrigger>
            <SelectContent>
              {mockDoctors.map((doctor) => (
                <SelectItem key={doctor.id} value={doctor.id}>
                  <div className="flex items-center gap-2">
                    <span>{doctor.name}</span>
                    <span className="text-xs text-muted-foreground">({doctor.specialization})</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Test Selection */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground">Investigations</h3>
            <Badge variant="secondary" className="rounded-full">
              {formData.selectedTests.length} Selected
            </Badge>
          </div>

          {/* Search & Filter */}
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tests by name or code..."
                value={testSearch}
                onChange={(e) => setTestSearch(e.target.value)}
                onFocus={() => setShowTestPicker(true)}
                className="pl-10 rounded-xl h-10"
              />
            </div>

            {/* Category Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
              <Button
                variant={selectedCategory === 'all' ? 'default' : 'outline'}
                size="sm"
                className="rounded-full shrink-0 h-8"
                onClick={() => setSelectedCategory('all')}
              >
                All
              </Button>
              {testCategories.slice(0, 5).map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  size="sm"
                  className="rounded-full shrink-0 h-8"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Test List */}
          {(showTestPicker || formData.selectedTests.length > 0) && (
            <div className="space-y-2 max-h-64 overflow-y-auto custom-scrollbar">
              {filteredTests.map((test) => {
                const isSelected = formData.selectedTests.includes(test.id)
                return (
                  <button
                    key={test.id}
                    onClick={() => {
                      if (isSelected) {
                        setFormData({
                          ...formData,
                          selectedTests: formData.selectedTests.filter((id) => id !== test.id),
                        })
                      } else {
                        setFormData({
                          ...formData,
                          selectedTests: [...formData.selectedTests, test.id],
                        })
                      }
                    }}
                    className={cn(
                      "w-full flex items-center justify-between p-3 rounded-xl border transition-all",
                      isSelected 
                        ? "bg-primary/5 border-primary/30" 
                        : "bg-background border-border/50 hover:border-border"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "h-5 w-5 rounded-full border-2 flex items-center justify-center transition-all",
                        isSelected ? "bg-primary border-primary" : "border-muted-foreground/30"
                      )}>
                        {isSelected && <Check className="h-3 w-3 text-primary-foreground" />}
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-medium text-foreground">{test.name}</p>
                        <p className="text-xs text-muted-foreground">{test.code} • {test.category}</p>
                      </div>
                    </div>
                    <span className="text-sm font-semibold text-foreground">
                      Rs. {test.price}
                    </span>
                  </button>
                )
              })}
            </div>
          )}

          {/* Selected Tests Summary */}
          {selectedTestDetails.length > 0 && (
            <div className="pt-3 border-t border-border/50 space-y-2">
              {selectedTestDetails.map((test) => (
                <div key={test.id} className="flex items-center justify-between py-1">
                  <span className="text-sm text-foreground">{test.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Rs. {test.price}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 rounded-full"
                      onClick={() => setFormData({
                        ...formData,
                        selectedTests: formData.selectedTests.filter((id) => id !== test.id),
                      })}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Sample Options */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Sample Options</h3>
          
          {/* Priority */}
          <div className="flex gap-2">
            {(['Normal', 'Urgent', 'Emergency'] as Priority[]).map((priority) => (
              <Button
                key={priority}
                variant={formData.priority === priority ? 'default' : 'outline'}
                size="sm"
                className={cn(
                  "flex-1 rounded-xl h-9",
                  formData.priority === priority && priority === 'Emergency' && "bg-critical hover:bg-critical/90",
                  formData.priority === priority && priority === 'Urgent' && "bg-warning hover:bg-warning/90 text-warning-foreground"
                )}
                onClick={() => setFormData({ ...formData, priority })}
              >
                {priority === 'Emergency' && <AlertTriangle className="h-3 w-3 mr-1" />}
                {priority}
              </Button>
            ))}
          </div>

          {/* Toggles */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Home Collection</span>
              </div>
              <Switch
                checked={formData.isHomeCollection}
                onCheckedChange={(checked) => setFormData({ ...formData, isHomeCollection: checked })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-critical" />
                <span className="text-sm font-medium">Emergency Sample</span>
              </div>
              <Switch
                checked={formData.isEmergency}
                onCheckedChange={(checked) => setFormData({ ...formData, isEmergency: checked })}
              />
            </div>
          </div>
        </div>

        {/* Payment Section */}
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <CreditCard className="h-4 w-4 text-primary" />
            Payment Details
          </h3>

          {/* Discount & Coupon */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <Percent className="h-3 w-3" /> Discount %
              </Label>
              <Input
                type="number"
                placeholder="0"
                value={formData.discount || ''}
                onChange={(e) => setFormData({ ...formData, discount: Number(e.target.value) })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Coupon Code</Label>
              <Input
                placeholder="Enter code"
                value={formData.couponCode}
                onChange={(e) => setFormData({ ...formData, couponCode: e.target.value })}
                className="rounded-xl mt-1.5 h-10"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <Label className="text-xs text-muted-foreground">Payment Method</Label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {paymentMethods.slice(0, 3).map((method) => (
                <Button
                  key={method}
                  variant={formData.paymentMethod === method ? 'default' : 'outline'}
                  size="sm"
                  className="rounded-xl h-9"
                  onClick={() => setFormData({ ...formData, paymentMethod: method })}
                >
                  {method}
                </Button>
              ))}
            </div>
          </div>

          {/* Paid Amount */}
          <div>
            <Label className="text-xs text-muted-foreground flex items-center gap-1">
              <IndianRupee className="h-3 w-3" /> Paid Amount
            </Label>
            <Input
              type="number"
              placeholder="0"
              value={formData.paidAmount || ''}
              onChange={(e) => setFormData({ ...formData, paidAmount: Number(e.target.value) })}
              className="rounded-xl mt-1.5 h-10"
            />
          </div>

          {/* Summary */}
          <div className="pt-4 border-t border-border/50 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-medium">Rs. {subtotal.toLocaleString()}</span>
            </div>
            {formData.discount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Discount ({formData.discount}%)</span>
                <span className="font-medium text-success">- Rs. {discountAmount.toLocaleString()}</span>
              </div>
            )}
            <Separator className="my-2" />
            <div className="flex justify-between text-base">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-primary">Rs. {total.toLocaleString()}</span>
            </div>
            {formData.paidAmount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Paid</span>
                <span className="font-medium text-success">Rs. {formData.paidAmount.toLocaleString()}</span>
              </div>
            )}
            {dueAmount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Due Amount</span>
                <span className="font-semibold text-critical">Rs. {dueAmount.toLocaleString()}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fixed Submit Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-card/95 backdrop-blur-xl border-t border-border/50">
        <Button 
          className="w-full h-12 rounded-xl text-base font-semibold"
          onClick={handleSubmit}
          disabled={!formData.name || formData.selectedTests.length === 0}
        >
          Submit Sample
        </Button>
      </div>
    </div>
  )
}
