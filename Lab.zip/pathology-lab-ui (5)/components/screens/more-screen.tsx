'use client'

import { 
  Building2, 
  Users, 
  UserCog, 
  Truck, 
  Package, 
  Cpu,
  Globe,
  Settings,
  Bell,
  Palette,
  MessageCircle,
  Mail,
  CreditCard,
  Database,
  ChevronRight,
  Shield,
  HelpCircle,
  LogOut,
  Moon,
  Sun,
  Stethoscope,
  Printer,
  QrCode,
  FileText
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import { useTheme } from 'next-themes'

interface MenuItem {
  id: string
  label: string
  description?: string
  icon: React.ElementType
  badge?: string
  badgeVariant?: 'default' | 'destructive' | 'warning'
  onClick?: () => void
}

interface MenuSection {
  title: string
  items: MenuItem[]
}

const menuSections: MenuSection[] = [
  {
    title: 'Lab Management',
    items: [
      { id: 'doctors', label: 'Referral Doctors', description: 'Manage doctor profiles & commissions', icon: Stethoscope },
      { id: 'staff', label: 'Staff Management', description: 'Roles & permissions', icon: UserCog },
      { id: 'branches', label: 'Branch Management', description: 'Multi-branch support', icon: Building2, badge: '3 Active' },
      { id: 'home-collection', label: 'Home Collection', description: 'Agents & scheduling', icon: Truck },
    ],
  },
  {
    title: 'Operations',
    items: [
      { id: 'inventory', label: 'Inventory', description: 'Reagents & consumables', icon: Package, badge: '2 Low', badgeVariant: 'warning' },
      { id: 'machines', label: 'Machine Integration', description: 'Analyzer connectivity', icon: Cpu },
      { id: 'patient-portal', label: 'Patient Portal', description: 'Online reports & booking', icon: Globe },
    ],
  },
  {
    title: 'Integrations',
    items: [
      { id: 'whatsapp', label: 'WhatsApp API', description: 'Configure messaging', icon: MessageCircle },
      { id: 'sms', label: 'SMS Gateway', description: 'SMS notifications', icon: Mail },
      { id: 'payment', label: 'Payment Gateway', description: 'UPI, Cards & more', icon: CreditCard },
      { id: 'printer', label: 'Printer Settings', description: 'Reports & barcodes', icon: Printer },
    ],
  },
  {
    title: 'System',
    items: [
      { id: 'notifications', label: 'Notifications', description: 'Alert preferences', icon: Bell },
      { id: 'backup', label: 'Backup & Restore', description: 'Data management', icon: Database },
      { id: 'settings', label: 'Lab Profile', description: 'Logo, details & GST', icon: Settings },
    ],
  },
]

interface MoreScreenProps {
  onNavigate?: (screen: string) => void
}

export function MoreScreen({ onNavigate }: MoreScreenProps) {
  const { theme, setTheme } = useTheme()

  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Profile Card */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center gap-4">
          <Avatar className="h-14 w-14">
            <AvatarFallback className="bg-primary text-primary-foreground text-lg font-bold">
              PL
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h2 className="text-base font-semibold text-foreground">PathLab Pro</h2>
            <p className="text-xs text-muted-foreground">Main Laboratory Branch</p>
            <Badge variant="secondary" className="mt-1.5 rounded-full text-[10px]">
              Premium Plan
            </Badge>
          </div>
          <Button variant="outline" size="sm" className="rounded-xl">
            Edit
          </Button>
        </div>
      </div>

      {/* Quick Settings */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
        <h3 className="text-sm font-semibold text-foreground">Quick Settings</h3>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {theme === 'dark' ? (
              <Moon className="h-5 w-5 text-primary" />
            ) : (
              <Sun className="h-5 w-5 text-warning" />
            )}
            <div>
              <p className="text-sm font-medium text-foreground">Dark Mode</p>
              <p className="text-xs text-muted-foreground">Toggle theme</p>
            </div>
          </div>
          <Switch
            checked={theme === 'dark'}
            onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
          />
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium text-foreground">Push Notifications</p>
              <p className="text-xs text-muted-foreground">Critical alerts</p>
            </div>
          </div>
          <Switch defaultChecked />
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <QrCode className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium text-foreground">QR Verification</p>
              <p className="text-xs text-muted-foreground">Report authentication</p>
            </div>
          </div>
          <Switch defaultChecked />
        </div>
      </div>

      {/* Menu Sections */}
      {menuSections.map((section) => (
        <div key={section.title} className="space-y-2">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-1">
            {section.title}
          </h3>
          <div className="bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden divide-y divide-border/50">
            {section.items.map((item) => {
              const Icon = item.icon
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate?.(item.id)}
                  className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors"
                >
                  <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-foreground">{item.label}</p>
                      {item.badge && (
                        <Badge 
                          variant={item.badgeVariant === 'warning' ? 'outline' : 'secondary'} 
                          className={cn(
                            "rounded-full text-[10px] px-1.5",
                            item.badgeVariant === 'warning' && "bg-warning/10 text-warning border-warning/30",
                            item.badgeVariant === 'destructive' && "bg-critical/10 text-critical"
                          )}
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    {item.description && (
                      <p className="text-xs text-muted-foreground">{item.description}</p>
                    )}
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </button>
              )
            })}
          </div>
        </div>
      ))}

      {/* Support & Help */}
      <div className="bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden divide-y divide-border/50">
        <button className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-info/10 flex items-center justify-center">
            <HelpCircle className="h-5 w-5 text-info" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-medium text-foreground">Help & Support</p>
            <p className="text-xs text-muted-foreground">FAQs & contact us</p>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </button>
        <button className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
            <Shield className="h-5 w-5 text-success" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-medium text-foreground">Privacy & Security</p>
            <p className="text-xs text-muted-foreground">Data protection settings</p>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </button>
        <button className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
            <FileText className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-medium text-foreground">Terms & Policies</p>
            <p className="text-xs text-muted-foreground">Legal information</p>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      {/* Logout Button */}
      <Button variant="outline" className="w-full h-12 rounded-xl text-critical border-critical/30 hover:bg-critical/10 hover:text-critical">
        <LogOut className="h-5 w-5 mr-2" />
        Log Out
      </Button>

      {/* Version Info */}
      <p className="text-center text-xs text-muted-foreground">
        PathLab Pro v2.0.1 | Made with care
      </p>
    </div>
  )
}
