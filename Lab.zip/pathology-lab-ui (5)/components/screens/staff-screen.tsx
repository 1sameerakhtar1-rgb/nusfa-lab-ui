'use client'

import { useState } from 'react'
import { 
  Search, 
  Plus, 
  User,
  Shield,
  MoreVertical,
  Edit,
  Trash2,
  Phone,
  Mail,
  Clock,
  CheckCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Switch } from '@/components/ui/switch'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { mockStaff } from '@/lib/mock-data'
import { StaffRole } from '@/lib/types'
import { cn } from '@/lib/utils'
import { formatDistanceToNow } from 'date-fns'

const roleColors: Record<StaffRole, { bg: string; color: string }> = {
  'Admin': { bg: 'bg-chart-4/10', color: 'text-chart-4' },
  'Receptionist': { bg: 'bg-primary/10', color: 'text-primary' },
  'Technician': { bg: 'bg-info/10', color: 'text-info' },
  'Pathologist': { bg: 'bg-success/10', color: 'text-success' },
  'Collection Agent': { bg: 'bg-warning/10', color: 'text-warning' },
}

const roleTabs: (StaffRole | 'All')[] = ['All', 'Admin', 'Receptionist', 'Technician', 'Pathologist', 'Collection Agent']

export function StaffScreen() {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeRole, setActiveRole] = useState<StaffRole | 'All'>('All')

  const filteredStaff = mockStaff.filter((staff) => {
    const matchesSearch = staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         staff.email.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesRole = activeRole === 'All' || staff.role === activeRole
    return matchesSearch && matchesRole
  })

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-card rounded-2xl border border-border/50 p-3 text-center">
          <p className="text-xl font-bold text-foreground">{mockStaff.length}</p>
          <p className="text-[10px] text-muted-foreground">Total Staff</p>
        </div>
        <div className="bg-success/10 border border-success/20 rounded-2xl p-3 text-center">
          <p className="text-xl font-bold text-success">{mockStaff.filter(s => s.isActive).length}</p>
          <p className="text-[10px] text-success">Active</p>
        </div>
        <div className="bg-muted rounded-2xl border border-border/50 p-3 text-center">
          <p className="text-xl font-bold text-muted-foreground">{mockStaff.filter(s => !s.isActive).length}</p>
          <p className="text-[10px] text-muted-foreground">Inactive</p>
        </div>
      </div>

      {/* Search & Add */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search staff..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 rounded-xl h-11 bg-card"
          />
        </div>
        <Button className="h-11 w-11 rounded-xl shrink-0" size="icon">
          <Plus className="h-5 w-5" />
        </Button>
      </div>

      {/* Role Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
        {roleTabs.map((role) => (
          <Button
            key={role}
            variant={activeRole === role ? 'default' : 'outline'}
            size="sm"
            className="rounded-full shrink-0 h-8 text-xs"
            onClick={() => setActiveRole(role)}
          >
            {role}
          </Button>
        ))}
      </div>

      {/* Staff List */}
      <div className="space-y-3">
        {filteredStaff.map((staff, index) => {
          const roleStyle = roleColors[staff.role]
          
          return (
            <div
              key={staff.id}
              className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className={cn("font-semibold", roleStyle.bg, roleStyle.color)}>
                        {staff.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className={cn(
                      "absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full border-2 border-card",
                      staff.isActive ? "bg-success" : "bg-muted-foreground"
                    )} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{staff.name}</p>
                    <Badge className={cn("rounded-full text-[10px] mt-1", roleStyle.bg, roleStyle.color)} variant="outline">
                      <Shield className="h-3 w-3 mr-1" />
                      {staff.role}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={staff.isActive} />
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 rounded-xl">
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" /> Edit Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Shield className="mr-2 h-4 w-4" /> Permissions
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-critical">
                        <Trash2 className="mr-2 h-4 w-4" /> Remove
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-2 mb-3">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Mail className="h-3.5 w-3.5" />
                  <span>{staff.email}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Phone className="h-3.5 w-3.5" />
                  <span>{staff.phone}</span>
                </div>
              </div>

              {/* Permissions */}
              <div className="flex flex-wrap gap-1.5 mb-3">
                {staff.permissions.slice(0, 3).map((permission) => (
                  <Badge key={permission} variant="secondary" className="rounded-lg text-[10px] px-2 py-0.5">
                    {permission}
                  </Badge>
                ))}
                {staff.permissions.length > 3 && (
                  <Badge variant="secondary" className="rounded-lg text-[10px] px-2 py-0.5">
                    +{staff.permissions.length - 3} more
                  </Badge>
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-border/50">
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  <span>Last active {formatDistanceToNow(staff.lastActive, { addSuffix: true })}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
