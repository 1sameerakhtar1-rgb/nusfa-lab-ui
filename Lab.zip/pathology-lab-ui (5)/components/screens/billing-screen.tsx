'use client'

import { useState } from 'react'
import { 
  Search, 
  Filter, 
  Receipt, 
  CheckCircle, 
  AlertCircle,
  MoreVertical,
  Download,
  Printer,
  IndianRupee,
  CreditCard,
  Smartphone,
  Wallet,
  Clock,
  RefreshCw,
  Eye,
  X,
  QrCode,
  Banknote,
  TrendingUp,
  Calendar,
  FileText,
  Send,
  Check,
  ChevronRight,
  Building2,
  Phone,
  Mail
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'
import { PaymentMethod } from '@/lib/types'

interface Invoice {
  id: string
  invoiceNumber: string
  patientName: string
  patientPhone: string
  patientEmail: string
  uhid: string
  tests: string[]
  subtotal: number
  discount: number
  discountType: 'percentage' | 'fixed'
  gst: number
  total: number
  paidAmount: number
  dueAmount: number
  paymentMethod: PaymentMethod
  isPaid: boolean
  createdAt: Date
  dueDate: Date
  referralDoctor?: string
}

const mockInvoices: Invoice[] = [
  { 
    id: '1', 
    invoiceNumber: 'INV2024001', 
    patientName: 'Rahul Kumar', 
    patientPhone: '+91 98765 43210',
    patientEmail: 'rahul.kumar@email.com',
    uhid: 'UHID2024001',
    tests: ['CBC', 'Lipid Profile', 'HbA1c'], 
    subtotal: 1500, 
    discount: 150, 
    discountType: 'percentage',
    gst: 243, 
    total: 1593, 
    paidAmount: 1593, 
    dueAmount: 0, 
    paymentMethod: 'UPI', 
    isPaid: true, 
    createdAt: new Date(),
    dueDate: new Date(),
    referralDoctor: 'Dr. Sharma'
  },
  { 
    id: '2', 
    invoiceNumber: 'INV2024002', 
    patientName: 'Priya Singh', 
    patientPhone: '+91 87654 32109',
    patientEmail: 'priya.singh@email.com',
    uhid: 'UHID2024002',
    tests: ['Thyroid Profile', 'Vitamin D'], 
    subtotal: 1800, 
    discount: 0, 
    discountType: 'fixed',
    gst: 324, 
    total: 2124, 
    paidAmount: 1000, 
    dueAmount: 1124, 
    paymentMethod: 'Cash', 
    isPaid: false, 
    createdAt: new Date(Date.now() - 86400000),
    dueDate: new Date(Date.now() + 604800000),
    referralDoctor: 'Dr. Patel'
  },
  { 
    id: '3', 
    invoiceNumber: 'INV2024003', 
    patientName: 'Amit Patel', 
    patientPhone: '+91 76543 21098',
    patientEmail: 'amit.patel@email.com',
    uhid: 'UHID2024003',
    tests: ['LFT', 'KFT', 'CBC', 'Urine R/M'], 
    subtotal: 2400, 
    discount: 240, 
    discountType: 'percentage',
    gst: 389, 
    total: 2549, 
    paidAmount: 2549, 
    dueAmount: 0, 
    paymentMethod: 'Card', 
    isPaid: true, 
    createdAt: new Date(Date.now() - 172800000),
    dueDate: new Date(Date.now() - 172800000)
  },
  { 
    id: '4', 
    invoiceNumber: 'INV2024004', 
    patientName: 'Sunita Verma', 
    patientPhone: '+91 65432 10987',
    patientEmail: 'sunita.verma@email.com',
    uhid: 'UHID2024004',
    tests: ['Vitamin D', 'B12', 'Iron Studies'], 
    subtotal: 2800, 
    discount: 200, 
    discountType: 'fixed',
    gst: 468, 
    total: 3068, 
    paidAmount: 0, 
    dueAmount: 3068, 
    paymentMethod: 'Cash', 
    isPaid: false, 
    createdAt: new Date(Date.now() - 259200000),
    dueDate: new Date(Date.now() + 432000000)
  },
  { 
    id: '5', 
    invoiceNumber: 'INV2024005', 
    patientName: 'Vikram Mehta', 
    patientPhone: '+91 54321 09876',
    patientEmail: 'vikram.mehta@email.com',
    uhid: 'UHID2024005',
    tests: ['CBC', 'ESR'], 
    subtotal: 450, 
    discount: 0, 
    discountType: 'fixed',
    gst: 81, 
    total: 531, 
    paidAmount: 531, 
    dueAmount: 0, 
    paymentMethod: 'UPI', 
    isPaid: true, 
    createdAt: new Date(Date.now() - 345600000),
    dueDate: new Date(Date.now() - 345600000)
  },
  { 
    id: '6', 
    invoiceNumber: 'INV2024006', 
    patientName: 'Neha Gupta', 
    patientPhone: '+91 43210 98765',
    patientEmail: 'neha.gupta@email.com',
    uhid: 'UHID2024006',
    tests: ['Complete Health Checkup'], 
    subtotal: 4500, 
    discount: 500, 
    discountType: 'fixed',
    gst: 720, 
    total: 4720, 
    paidAmount: 2000, 
    dueAmount: 2720, 
    paymentMethod: 'Card', 
    isPaid: false, 
    createdAt: new Date(Date.now() - 432000000),
    dueDate: new Date(Date.now() + 259200000),
    referralDoctor: 'Dr. Kapoor'
  },
]

const paymentMethodIcons: Record<PaymentMethod, React.ElementType> = {
  'Cash': Wallet,
  'Card': CreditCard,
  'UPI': Smartphone,
  'Net Banking': CreditCard,
  'Cheque': Receipt,
}

const filterTabs = ['All', 'Paid', 'Unpaid', 'Partial']

export function BillingScreen() {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState('All')
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null)
  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentAmount, setPaymentAmount] = useState('')
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod>('UPI')
  const [showPaymentSuccess, setShowPaymentSuccess] = useState(false)

  const getInvoiceStatus = (invoice: Invoice) => {
    if (invoice.isPaid) return 'Paid'
    if (invoice.paidAmount > 0) return 'Partial'
    return 'Unpaid'
  }

  const filteredInvoices = mockInvoices.filter((invoice) => {
    const matchesSearch = 
      invoice.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.uhid.toLowerCase().includes(searchQuery.toLowerCase())
    const status = getInvoiceStatus(invoice)
    const matchesFilter = activeFilter === 'All' || status === activeFilter
    return matchesSearch && matchesFilter
  })

  const totalRevenue = mockInvoices.reduce((sum, inv) => sum + inv.total, 0)
  const totalCollected = mockInvoices.reduce((sum, inv) => sum + inv.paidAmount, 0)
  const totalDue = mockInvoices.reduce((sum, inv) => sum + inv.dueAmount, 0)
  const paidCount = mockInvoices.filter(inv => inv.isPaid).length
  const unpaidCount = mockInvoices.filter(inv => !inv.isPaid && inv.paidAmount === 0).length

  const handleViewInvoice = (invoice: Invoice) => {
    setSelectedInvoice(invoice)
    setShowInvoiceModal(true)
  }

  const handleCollectPayment = (invoice: Invoice) => {
    setSelectedInvoice(invoice)
    setPaymentAmount(invoice.dueAmount.toString())
    setShowPaymentModal(true)
  }

  const handlePaymentSubmit = () => {
    setShowPaymentSuccess(true)
    setTimeout(() => {
      setShowPaymentSuccess(false)
      setShowPaymentModal(false)
      setSelectedInvoice(null)
    }, 2000)
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-IN', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric' 
    })
  }

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Revenue Summary Cards */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 rounded-2xl p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <TrendingUp className="h-3.5 w-3.5 text-primary" />
            <span className="text-[10px] text-primary font-medium">Revenue</span>
          </div>
          <p className="text-lg font-bold text-primary">Rs.{(totalRevenue / 1000).toFixed(1)}k</p>
        </div>
        <div className="bg-gradient-to-br from-success/10 to-success/5 border border-success/20 rounded-2xl p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <CheckCircle className="h-3.5 w-3.5 text-success" />
            <span className="text-[10px] text-success font-medium">Collected</span>
          </div>
          <p className="text-lg font-bold text-success">Rs.{(totalCollected / 1000).toFixed(1)}k</p>
        </div>
        <div className="bg-gradient-to-br from-critical/10 to-critical/5 border border-critical/20 rounded-2xl p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <Clock className="h-3.5 w-3.5 text-critical" />
            <span className="text-[10px] text-critical font-medium">Pending</span>
          </div>
          <p className="text-lg font-bold text-critical">Rs.{(totalDue / 1000).toFixed(1)}k</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="flex gap-3">
        <div className="flex-1 bg-card border border-border/50 rounded-xl p-3 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
            <Receipt className="h-5 w-5 text-success" />
          </div>
          <div>
            <p className="text-xl font-bold text-foreground">{paidCount}</p>
            <p className="text-[10px] text-muted-foreground">Paid Invoices</p>
          </div>
        </div>
        <div className="flex-1 bg-card border border-border/50 rounded-xl p-3 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-critical/10 flex items-center justify-center">
            <AlertCircle className="h-5 w-5 text-critical" />
          </div>
          <div>
            <p className="text-xl font-bold text-foreground">{unpaidCount}</p>
            <p className="text-[10px] text-muted-foreground">Unpaid Invoices</p>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search invoices, patients, UHID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 pr-10 rounded-xl h-11 bg-card border-border/50"
        />
        <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg">
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
        {filterTabs.map((tab) => {
          const count = mockInvoices.filter((inv) => {
            if (tab === 'All') return true
            return getInvoiceStatus(inv) === tab
          }).length

          return (
            <Button
              key={tab}
              variant={activeFilter === tab ? 'default' : 'outline'}
              size="sm"
              className={cn(
                "rounded-full shrink-0 h-8",
                tab === 'Unpaid' && activeFilter === tab && "bg-critical hover:bg-critical/90",
                tab === 'Paid' && activeFilter === tab && "bg-success hover:bg-success/90"
              )}
              onClick={() => setActiveFilter(tab)}
            >
              {tab}
              <Badge variant="secondary" className="ml-1.5 px-1.5 py-0 text-[10px] rounded-full bg-white/20">
                {count}
              </Badge>
            </Button>
          )
        })}
      </div>

      {/* Invoices List */}
      <div className="space-y-3">
        {filteredInvoices.map((invoice, index) => {
          const status = getInvoiceStatus(invoice)
          const PaymentIcon = paymentMethodIcons[invoice.paymentMethod]

          return (
            <div
              key={invoice.id}
              className={cn(
                "bg-card rounded-2xl border p-4 shadow-sm animate-slide-up",
                !invoice.isPaid && invoice.paidAmount === 0
                  ? "border-critical/30" 
                  : invoice.paidAmount > 0 && !invoice.isPaid
                    ? "border-warning/30"
                    : "border-border/50"
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "h-11 w-11 rounded-xl flex items-center justify-center",
                    invoice.isPaid 
                      ? "bg-success/10" 
                      : invoice.paidAmount > 0 
                        ? "bg-warning/10" 
                        : "bg-critical/10"
                  )}>
                    <Receipt className={cn(
                      "h-5 w-5",
                      invoice.isPaid 
                        ? "text-success" 
                        : invoice.paidAmount > 0 
                          ? "text-warning" 
                          : "text-critical"
                    )} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{invoice.patientName}</p>
                    <div className="flex items-center gap-2">
                      <p className="text-xs text-muted-foreground font-mono">{invoice.invoiceNumber}</p>
                      <span className="text-muted-foreground/50">|</span>
                      <p className="text-xs text-muted-foreground">{invoice.uhid}</p>
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 rounded-xl">
                    <DropdownMenuItem onClick={() => handleViewInvoice(invoice)}>
                      <Eye className="mr-2 h-4 w-4" /> View Invoice
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Download className="mr-2 h-4 w-4" /> Download PDF
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Printer className="mr-2 h-4 w-4" /> Print Invoice
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Send className="mr-2 h-4 w-4" /> Send via WhatsApp
                    </DropdownMenuItem>
                    {!invoice.isPaid && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleCollectPayment(invoice)}>
                          <IndianRupee className="mr-2 h-4 w-4" /> Collect Payment
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-critical">
                      <RefreshCw className="mr-2 h-4 w-4" /> Process Refund
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Tests */}
              <div className="flex flex-wrap gap-1.5 mb-3">
                {invoice.tests.map((test) => (
                  <Badge key={test} variant="secondary" className="rounded-lg text-[10px] px-2 py-0.5 bg-muted/50">
                    {test}
                  </Badge>
                ))}
              </div>

              {/* Amount Summary */}
              <div className="flex items-center justify-between p-2.5 bg-muted/30 rounded-xl mb-3">
                <div className="text-center flex-1 border-r border-border/50">
                  <p className="text-[10px] text-muted-foreground">Total</p>
                  <p className="text-sm font-bold text-foreground">Rs.{invoice.total.toLocaleString()}</p>
                </div>
                <div className="text-center flex-1 border-r border-border/50">
                  <p className="text-[10px] text-muted-foreground">Paid</p>
                  <p className="text-sm font-bold text-success">Rs.{invoice.paidAmount.toLocaleString()}</p>
                </div>
                <div className="text-center flex-1">
                  <p className="text-[10px] text-muted-foreground">Due</p>
                  <p className={cn(
                    "text-sm font-bold",
                    invoice.dueAmount > 0 ? "text-critical" : "text-muted-foreground"
                  )}>Rs.{invoice.dueAmount.toLocaleString()}</p>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge 
                    className={cn(
                      "rounded-full text-[10px] font-medium border-0",
                      status === 'Paid' 
                        ? "bg-success/10 text-success" 
                        : status === 'Partial' 
                          ? "bg-warning/10 text-warning" 
                          : "bg-critical/10 text-critical"
                    )} 
                  >
                    {status === 'Paid' && <CheckCircle className="h-3 w-3 mr-1" />}
                    {status === 'Unpaid' && <AlertCircle className="h-3 w-3 mr-1" />}
                    {status === 'Partial' && <Clock className="h-3 w-3 mr-1" />}
                    {status}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground bg-muted/30 px-2 py-0.5 rounded-full">
                    <PaymentIcon className="h-3 w-3" />
                    <span>{invoice.paymentMethod}</span>
                  </div>
                </div>
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {formatDate(invoice.createdAt)}
                </span>
              </div>

              {/* Collect Payment Button */}
              {!invoice.isPaid && (
                <Button 
                  className="w-full mt-3 rounded-xl h-10 bg-primary hover:bg-primary/90" 
                  size="sm"
                  onClick={() => handleCollectPayment(invoice)}
                >
                  <IndianRupee className="h-4 w-4 mr-1.5" />
                  Collect Rs.{invoice.dueAmount.toLocaleString()}
                </Button>
              )}
            </div>
          )
        })}
      </div>

      {/* Invoice Preview Modal */}
      {showInvoiceModal && selectedInvoice && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center animate-fade-in">
          <div className="bg-card w-full max-w-md rounded-t-3xl max-h-[90vh] overflow-hidden animate-slide-up">
            {/* Modal Header */}
            <div className="sticky top-0 bg-card border-b border-border/50 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Invoice Details</h3>
                  <p className="text-xs text-muted-foreground">{selectedInvoice.invoiceNumber}</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full h-8 w-8"
                onClick={() => setShowInvoiceModal(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Invoice Content */}
            <div className="overflow-y-auto p-4 space-y-4 max-h-[calc(90vh-180px)]">
              {/* Lab Header */}
              <div className="text-center p-4 bg-gradient-to-r from-primary/5 to-primary/10 rounded-2xl border border-primary/20">
                <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center mx-auto mb-2">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
                <h4 className="font-bold text-foreground">PathLab Pro Diagnostics</h4>
                <p className="text-xs text-muted-foreground">123 Medical Plaza, Healthcare District</p>
                <p className="text-xs text-muted-foreground">Phone: +91 1234567890 | GSTIN: 27XXXXX1234X1Z5</p>
              </div>

              {/* Patient Details */}
              <div className="bg-muted/30 rounded-xl p-3 space-y-2">
                <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Patient Details</h5>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[10px] text-muted-foreground">Name</p>
                    <p className="text-sm font-medium">{selectedInvoice.patientName}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground">UHID</p>
                    <p className="text-sm font-medium font-mono">{selectedInvoice.uhid}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Phone className="h-3 w-3 text-muted-foreground" />
                    <p className="text-xs">{selectedInvoice.patientPhone}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Mail className="h-3 w-3 text-muted-foreground" />
                    <p className="text-xs truncate">{selectedInvoice.patientEmail}</p>
                  </div>
                </div>
                {selectedInvoice.referralDoctor && (
                  <div className="pt-2 border-t border-border/50">
                    <p className="text-[10px] text-muted-foreground">Referred By</p>
                    <p className="text-sm font-medium">{selectedInvoice.referralDoctor}</p>
                  </div>
                )}
              </div>

              {/* Tests */}
              <div className="bg-muted/30 rounded-xl p-3 space-y-2">
                <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Tests</h5>
                <div className="space-y-2">
                  {selectedInvoice.tests.map((test, idx) => (
                    <div key={idx} className="flex items-center justify-between py-1.5 border-b border-border/30 last:border-0">
                      <span className="text-sm">{test}</span>
                      <span className="text-sm font-medium">Rs.{Math.round(selectedInvoice.subtotal / selectedInvoice.tests.length)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Amount Breakdown */}
              <div className="bg-muted/30 rounded-xl p-3 space-y-2">
                <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Amount Details</h5>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>Rs.{selectedInvoice.subtotal.toLocaleString()}</span>
                  </div>
                  {selectedInvoice.discount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Discount</span>
                      <span className="text-success">- Rs.{selectedInvoice.discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">GST (18%)</span>
                    <span>Rs.{selectedInvoice.gst.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm pt-2 border-t border-border/50 font-bold">
                    <span>Grand Total</span>
                    <span className="text-primary">Rs.{selectedInvoice.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Payment Status */}
              <div className={cn(
                "rounded-xl p-3 flex items-center justify-between",
                selectedInvoice.isPaid 
                  ? "bg-success/10 border border-success/30" 
                  : "bg-critical/10 border border-critical/30"
              )}>
                <div className="flex items-center gap-2">
                  {selectedInvoice.isPaid ? (
                    <CheckCircle className="h-5 w-5 text-success" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-critical" />
                  )}
                  <div>
                    <p className={cn(
                      "text-sm font-semibold",
                      selectedInvoice.isPaid ? "text-success" : "text-critical"
                    )}>
                      {selectedInvoice.isPaid ? 'Fully Paid' : `Due: Rs.${selectedInvoice.dueAmount.toLocaleString()}`}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Paid: Rs.{selectedInvoice.paidAmount.toLocaleString()} via {selectedInvoice.paymentMethod}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-card border-t border-border/50 p-4 flex gap-2">
              <Button variant="outline" className="flex-1 rounded-xl h-11">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button variant="outline" className="flex-1 rounded-xl h-11">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button className="flex-1 rounded-xl h-11 bg-green-600 hover:bg-green-700">
                <Send className="h-4 w-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Collection Modal */}
      {showPaymentModal && selectedInvoice && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center animate-fade-in">
          <div className="bg-card w-full max-w-md rounded-t-3xl animate-slide-up">
            {showPaymentSuccess ? (
              /* Success State */
              <div className="p-8 text-center">
                <div className="h-20 w-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4 animate-scale-in">
                  <Check className="h-10 w-10 text-success" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">Payment Successful!</h3>
                <p className="text-muted-foreground">Rs.{parseFloat(paymentAmount).toLocaleString()} collected from {selectedInvoice.patientName}</p>
              </div>
            ) : (
              <>
                {/* Modal Header */}
                <div className="p-4 border-b border-border/50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <IndianRupee className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Collect Payment</h3>
                      <p className="text-xs text-muted-foreground">{selectedInvoice.patientName}</p>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full h-8 w-8"
                    onClick={() => setShowPaymentModal(false)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                {/* Payment Content */}
                <div className="p-4 space-y-4">
                  {/* Due Amount */}
                  <div className="bg-critical/10 border border-critical/30 rounded-xl p-4 text-center">
                    <p className="text-xs text-critical mb-1">Due Amount</p>
                    <p className="text-3xl font-bold text-critical">Rs.{selectedInvoice.dueAmount.toLocaleString()}</p>
                  </div>

                  {/* Payment Amount Input */}
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-2 block">Amount to Collect</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">Rs.</span>
                      <Input
                        type="number"
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(e.target.value)}
                        className="pl-12 h-14 text-xl font-bold rounded-xl"
                        placeholder="0"
                      />
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 rounded-lg text-xs"
                        onClick={() => setPaymentAmount(selectedInvoice.dueAmount.toString())}
                      >
                        Full Amount
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 rounded-lg text-xs"
                        onClick={() => setPaymentAmount((selectedInvoice.dueAmount / 2).toString())}
                      >
                        50%
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 rounded-lg text-xs"
                        onClick={() => setPaymentAmount('1000')}
                      >
                        Rs.1000
                      </Button>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-2 block">Payment Method</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { method: 'UPI' as PaymentMethod, icon: QrCode, label: 'UPI / QR' },
                        { method: 'Cash' as PaymentMethod, icon: Banknote, label: 'Cash' },
                        { method: 'Card' as PaymentMethod, icon: CreditCard, label: 'Card' },
                        { method: 'Net Banking' as PaymentMethod, icon: Smartphone, label: 'Net Banking' },
                      ].map(({ method, icon: Icon, label }) => (
                        <button
                          key={method}
                          className={cn(
                            "flex items-center gap-3 p-3 rounded-xl border-2 transition-all",
                            selectedPaymentMethod === method
                              ? "border-primary bg-primary/5"
                              : "border-border/50 hover:border-primary/50"
                          )}
                          onClick={() => setSelectedPaymentMethod(method)}
                        >
                          <div className={cn(
                            "h-10 w-10 rounded-xl flex items-center justify-center",
                            selectedPaymentMethod === method ? "bg-primary/10" : "bg-muted/50"
                          )}>
                            <Icon className={cn(
                              "h-5 w-5",
                              selectedPaymentMethod === method ? "text-primary" : "text-muted-foreground"
                            )} />
                          </div>
                          <span className={cn(
                            "text-sm font-medium",
                            selectedPaymentMethod === method ? "text-primary" : "text-foreground"
                          )}>{label}</span>
                          {selectedPaymentMethod === method && (
                            <Check className="h-4 w-4 text-primary ml-auto" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="p-4 border-t border-border/50">
                  <Button 
                    className="w-full h-12 rounded-xl text-base font-semibold"
                    onClick={handlePaymentSubmit}
                    disabled={!paymentAmount || parseFloat(paymentAmount) <= 0}
                  >
                    <IndianRupee className="h-5 w-5 mr-2" />
                    Collect Rs.{parseFloat(paymentAmount || '0').toLocaleString()}
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
