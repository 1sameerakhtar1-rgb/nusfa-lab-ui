'use client'

import { 
  IndianRupee, 
  TestTube2, 
  FileText, 
  Clock,
  Users,
  Beaker,
  AlertTriangle,
  TrendingUp
} from 'lucide-react'
import { StatCard } from '@/components/dashboard/stat-card'
import { QuickActions } from '@/components/dashboard/quick-actions'
import { ActivityTimeline } from '@/components/dashboard/activity-timeline'
import { RevenueChart } from '@/components/dashboard/revenue-chart'
import { PopularTests } from '@/components/dashboard/popular-tests'
import { NotificationsPanel } from '@/components/dashboard/notifications-panel'
import { DoctorAnalytics } from '@/components/dashboard/doctor-analytics'
import { CollectionCenters } from '@/components/dashboard/collection-centers'
import { mockDashboardStats, mockNotifications, mockActivities } from '@/lib/mock-data'

interface DashboardScreenProps {
  onAction: (action: string) => void
}

export function DashboardScreen({ onAction }: DashboardScreenProps) {
  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary to-primary/80 p-4 text-primary-foreground">
        <div className="relative z-10">
          <p className="text-xs opacity-90">Good Morning</p>
          <h2 className="text-lg font-bold mt-1">Welcome back, Admin</h2>
          <p className="text-xs mt-2 opacity-80">
            You have {mockDashboardStats.pendingReports} pending reports and {mockDashboardStats.totalSamples} samples to process today.
          </p>
        </div>
        <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-20">
          <Beaker className="h-24 w-24" />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          title="Monthly Revenue"
          value={`Rs. ${(mockDashboardStats.monthlyRevenue / 100000).toFixed(1)}L`}
          icon={IndianRupee}
          variant="primary"
          trend={{ value: 12.5, isPositive: true }}
          subtitle="vs last month"
        />
        <StatCard
          title="Daily Collection"
          value={`Rs. ${mockDashboardStats.dailyCollection.toLocaleString()}`}
          icon={TrendingUp}
          variant="success"
          trend={{ value: 8.2, isPositive: true }}
        />
        <StatCard
          title="Pending Reports"
          value={mockDashboardStats.pendingReports}
          icon={Clock}
          variant="warning"
        />
        <StatCard
          title="Reports Delivered"
          value={mockDashboardStats.reportsDelivered}
          icon={FileText}
          variant="default"
          trend={{ value: 15, isPositive: true }}
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-3 gap-3">
        <StatCard
          title="Samples"
          value={mockDashboardStats.totalSamples}
          icon={TestTube2}
          variant="primary"
          className="col-span-1"
        />
        <StatCard
          title="Patients"
          value={mockDashboardStats.activePatients}
          icon={Users}
          variant="success"
          className="col-span-1"
        />
        <StatCard
          title="Pending Dues"
          value={`Rs. ${(mockDashboardStats.pendingPayments / 1000).toFixed(0)}K`}
          icon={AlertTriangle}
          variant="critical"
          className="col-span-1"
        />
      </div>

      {/* Quick Actions */}
      <QuickActions onAction={onAction} />

      {/* Revenue Chart */}
      <RevenueChart />

      {/* Notifications */}
      <NotificationsPanel notifications={mockNotifications} />

      {/* Popular Tests */}
      <PopularTests />

      {/* Doctor Analytics */}
      <DoctorAnalytics />

      {/* Collection Centers */}
      <CollectionCenters />

      {/* Activity Timeline */}
      <ActivityTimeline activities={mockActivities} />
    </div>
  )
}
