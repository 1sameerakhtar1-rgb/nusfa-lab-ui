'use client'

import { useState } from 'react'
import { 
  ArrowLeft,
  Building2, 
  Users, 
  UserCog, 
  Printer,
  MessageCircle,
  Mail,
  CreditCard,
  Database,
  ChevronRight,
  Shield,
  HelpCircle,
  LogOut,
  Moon,
  Sun,
  QrCode,
  Bell,
  Globe,
  Palette,
  Phone,
  MapPin,
  FileText,
  Upload,
  Download,
  Check,
  X,
  Edit,
  Camera,
  Save,
  IndianRupee,
  Percent,
  Clock,
  Wifi,
  WifiOff,
  TestTube,
  Plus,
  Trash2,
  ToggleLeft,
  ToggleRight,
  ExternalLink
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/lib/utils'
import { useTheme } from 'next-themes'

interface SettingsSection {
  id: string
  title: string
  description: string
  icon: React.ElementType
  badge?: string
  badgeVariant?: 'success' | 'warning' | 'critical'
}

const settingsSections: SettingsSection[] = [
  { id: 'lab-profile', title: 'Lab Profile', description: 'Lab details, logo & GST', icon: Building2 },
  { id: 'branches', title: 'Branch Management', description: 'Manage multiple branches', icon: Globe, badge: '3 Active' },
  { id: 'staff', title: 'Staff Management', description: 'Roles & permissions', icon: UserCog },
  { id: 'printer', title: 'Printer Settings', description: 'Reports & barcode printing', icon: Printer },
  { id: 'whatsapp', title: 'WhatsApp API', description: 'Configure messaging', icon: MessageCircle, badge: 'Connected', badgeVariant: 'success' },
  { id: 'sms', title: 'SMS Gateway', description: 'SMS notifications', icon: Mail, badge: 'Setup', badgeVariant: 'warning' },
  { id: 'payment', title: 'Payment Gateway', description: 'UPI, Cards & online payments', icon: CreditCard, badge: 'Active', badgeVariant: 'success' },
  { id: 'backup', title: 'Backup & Restore', description: 'Data management & recovery', icon: Database },
]

interface SettingsScreenProps {
  onBack?: () => void
  onLogout?: () => void
}

export function SettingsScreen({ onBack, onLogout }: SettingsScreenProps) {
  const { theme, setTheme } = useTheme()
  const [activeSection, setActiveSection] = useState<string | null>(null)
  const [labProfile, setLabProfile] = useState({
    name: 'PathLab Pro Diagnostics',
    address: '123 Healthcare Street, Medical District',
    city: 'Mumbai',
    pincode: '400001',
    phone: '+91 98765 11111',
    email: 'info@pathlabpro.com',
    website: 'www.pathlabpro.com',
    gstNumber: '27AABCT1234A1ZA',
    panNumber: 'AABCT1234A',
    registrationNumber: 'ML-2024-001234',
    openTime: '08:00',
    closeTime: '20:00',
    reportFooter: 'Thank you for choosing PathLab Pro. For queries, contact us at support@pathlabpro.com'
  })
  const [whatsappSettings, setWhatsappSettings] = useState({
    enabled: true,
    apiKey: 'wh_xxxxxxxxxxxxxxxx',
    phoneNumber: '+91 98765 11111',
    autoSendReport: true,
    autoSendReminder: true,
    reminderTime: '09:00'
  })
  const [printerSettings, setPrinterSettings] = useState({
    reportPrinter: 'HP LaserJet Pro',
    barcodePrinter: 'Zebra ZD420',
    paperSize: 'A4',
    printPreview: true,
    autoPrintBarcode: true,
    copies: 1
  })
  const [backupSettings, setBackupSettings] = useState({
    autoBackup: true,
    backupFrequency: 'daily',
    lastBackup: new Date(Date.now() - 3600000),
    cloudSync: true
  })
  
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-IN', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'lab-profile':
        return (
          <div className="space-y-4">
            {/* Lab Logo */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Avatar className="h-20 w-20">
                    <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">
                      PL
                    </AvatarFallback>
                  </Avatar>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-card shadow-sm"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-foreground">{labProfile.name}</h3>
                  <p className="text-xs text-muted-foreground">Click to change logo</p>
                  <Badge variant="secondary" className="mt-2 rounded-full text-[10px]">
                    Premium Plan
                  </Badge>
                </div>
              </div>
            </div>

            {/* Basic Info */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Building2 className="h-4 w-4 text-primary" />
                Basic Information
              </h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Lab Name</Label>
                  <Input
                    value={labProfile.name}
                    onChange={(e) => setLabProfile({ ...labProfile, name: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
                
                <div>
                  <Label className="text-xs text-muted-foreground">Address</Label>
                  <Textarea
                    value={labProfile.address}
                    onChange={(e) => setLabProfile({ ...labProfile, address: e.target.value })}
                    className="rounded-xl mt-1.5 min-h-[80px]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-muted-foreground">City</Label>
                    <Input
                      value={labProfile.city}
                      onChange={(e) => setLabProfile({ ...labProfile, city: e.target.value })}
                      className="rounded-xl mt-1.5 h-10"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">PIN Code</Label>
                    <Input
                      value={labProfile.pincode}
                      onChange={(e) => setLabProfile({ ...labProfile, pincode: e.target.value })}
                      className="rounded-xl mt-1.5 h-10"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                Contact Information
              </h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Phone Number</Label>
                  <Input
                    value={labProfile.phone}
                    onChange={(e) => setLabProfile({ ...labProfile, phone: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Email</Label>
                  <Input
                    type="email"
                    value={labProfile.email}
                    onChange={(e) => setLabProfile({ ...labProfile, email: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Website</Label>
                  <Input
                    value={labProfile.website}
                    onChange={(e) => setLabProfile({ ...labProfile, website: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
              </div>
            </div>

            {/* Tax & Registration */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                Tax & Registration
              </h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">GST Number</Label>
                  <Input
                    value={labProfile.gstNumber}
                    onChange={(e) => setLabProfile({ ...labProfile, gstNumber: e.target.value })}
                    className="rounded-xl mt-1.5 h-10 font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-muted-foreground">PAN Number</Label>
                    <Input
                      value={labProfile.panNumber}
                      onChange={(e) => setLabProfile({ ...labProfile, panNumber: e.target.value })}
                      className="rounded-xl mt-1.5 h-10 font-mono"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Reg. Number</Label>
                    <Input
                      value={labProfile.registrationNumber}
                      onChange={(e) => setLabProfile({ ...labProfile, registrationNumber: e.target.value })}
                      className="rounded-xl mt-1.5 h-10 font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Working Hours */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                Working Hours
              </h3>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Opening Time</Label>
                  <Input
                    type="time"
                    value={labProfile.openTime}
                    onChange={(e) => setLabProfile({ ...labProfile, openTime: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Closing Time</Label>
                  <Input
                    type="time"
                    value={labProfile.closeTime}
                    onChange={(e) => setLabProfile({ ...labProfile, closeTime: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
              </div>
            </div>

            {/* Report Footer */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground">Report Footer Text</h3>
              <Textarea
                value={labProfile.reportFooter}
                onChange={(e) => setLabProfile({ ...labProfile, reportFooter: e.target.value })}
                className="rounded-xl min-h-[80px]"
                placeholder="Text to appear at bottom of reports..."
              />
            </div>

            {/* Save Button */}
            <Button className="w-full h-12 rounded-xl gap-2">
              <Save className="h-4 w-4" />
              Save Changes
            </Button>
          </div>
        )

      case 'whatsapp':
        return (
          <div className="space-y-4">
            {/* Connection Status */}
            <div className={cn(
              "rounded-2xl border p-4 shadow-sm",
              whatsappSettings.enabled 
                ? "bg-success/5 border-success/20" 
                : "bg-muted border-border/50"
            )}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "h-12 w-12 rounded-xl flex items-center justify-center",
                    whatsappSettings.enabled ? "bg-success/10" : "bg-muted"
                  )}>
                    {whatsappSettings.enabled ? (
                      <Wifi className="h-6 w-6 text-success" />
                    ) : (
                      <WifiOff className="h-6 w-6 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {whatsappSettings.enabled ? 'Connected' : 'Disconnected'}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {whatsappSettings.enabled ? 'WhatsApp API is active' : 'Click to connect'}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={whatsappSettings.enabled}
                  onCheckedChange={(checked) => setWhatsappSettings({ ...whatsappSettings, enabled: checked })}
                />
              </div>
            </div>

            {/* API Configuration */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-success" />
                API Configuration
              </h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">API Key</Label>
                  <Input
                    type="password"
                    value={whatsappSettings.apiKey}
                    onChange={(e) => setWhatsappSettings({ ...whatsappSettings, apiKey: e.target.value })}
                    className="rounded-xl mt-1.5 h-10 font-mono"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">WhatsApp Business Number</Label>
                  <Input
                    value={whatsappSettings.phoneNumber}
                    onChange={(e) => setWhatsappSettings({ ...whatsappSettings, phoneNumber: e.target.value })}
                    className="rounded-xl mt-1.5 h-10"
                  />
                </div>
              </div>
            </div>

            {/* Automation Settings */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground">Automation</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Auto Send Reports</p>
                    <p className="text-xs text-muted-foreground">Send report automatically when ready</p>
                  </div>
                  <Switch
                    checked={whatsappSettings.autoSendReport}
                    onCheckedChange={(checked) => setWhatsappSettings({ ...whatsappSettings, autoSendReport: checked })}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Collection Reminders</p>
                    <p className="text-xs text-muted-foreground">Remind patients about sample collection</p>
                  </div>
                  <Switch
                    checked={whatsappSettings.autoSendReminder}
                    onCheckedChange={(checked) => setWhatsappSettings({ ...whatsappSettings, autoSendReminder: checked })}
                  />
                </div>

                {whatsappSettings.autoSendReminder && (
                  <div>
                    <Label className="text-xs text-muted-foreground">Reminder Time</Label>
                    <Input
                      type="time"
                      value={whatsappSettings.reminderTime}
                      onChange={(e) => setWhatsappSettings({ ...whatsappSettings, reminderTime: e.target.value })}
                      className="rounded-xl mt-1.5 h-10"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Test Message */}
            <Button variant="outline" className="w-full h-11 rounded-xl gap-2">
              <MessageCircle className="h-4 w-4" />
              Send Test Message
            </Button>
          </div>
        )

      case 'printer':
        return (
          <div className="space-y-4">
            {/* Report Printer */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Printer className="h-4 w-4 text-primary" />
                Report Printer
              </h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Printer Name</Label>
                  <Input
                    value={printerSettings.reportPrinter}
                    className="rounded-xl mt-1.5 h-10"
                    readOnly
                  />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 rounded-xl h-10">
                    Select Printer
                  </Button>
                  <Button variant="outline" className="rounded-xl h-10 w-10" size="icon">
                    <TestTube className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Barcode Printer */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground">Barcode Printer</h3>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Printer Name</Label>
                  <Input
                    value={printerSettings.barcodePrinter}
                    className="rounded-xl mt-1.5 h-10"
                    readOnly
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Auto Print Barcode</p>
                    <p className="text-xs text-muted-foreground">Print on sample registration</p>
                  </div>
                  <Switch
                    checked={printerSettings.autoPrintBarcode}
                    onCheckedChange={(checked) => setPrinterSettings({ ...printerSettings, autoPrintBarcode: checked })}
                  />
                </div>
              </div>
            </div>

            {/* Print Settings */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <h3 className="text-sm font-semibold text-foreground">Print Settings</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">Print Preview</p>
                    <p className="text-xs text-muted-foreground">Show preview before printing</p>
                  </div>
                  <Switch
                    checked={printerSettings.printPreview}
                    onCheckedChange={(checked) => setPrinterSettings({ ...printerSettings, printPreview: checked })}
                  />
                </div>

                <Separator />

                <div>
                  <Label className="text-xs text-muted-foreground">Paper Size</Label>
                  <div className="flex gap-2 mt-2">
                    {['A4', 'A5', 'Letter'].map((size) => (
                      <Button
                        key={size}
                        variant={printerSettings.paperSize === size ? 'default' : 'outline'}
                        size="sm"
                        className="flex-1 rounded-xl h-9"
                        onClick={() => setPrinterSettings({ ...printerSettings, paperSize: size })}
                      >
                        {size}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-xs text-muted-foreground">Default Copies</Label>
                  <div className="flex items-center gap-3 mt-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-10 w-10 rounded-xl"
                      onClick={() => setPrinterSettings({ ...printerSettings, copies: Math.max(1, printerSettings.copies - 1) })}
                    >
                      -
                    </Button>
                    <span className="text-lg font-semibold w-8 text-center">{printerSettings.copies}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-10 w-10 rounded-xl"
                      onClick={() => setPrinterSettings({ ...printerSettings, copies: printerSettings.copies + 1 })}
                    >
                      +
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      case 'backup':
        return (
          <div className="space-y-4">
            {/* Last Backup Status */}
            <div className="bg-success/5 border border-success/20 rounded-2xl p-4 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-xl bg-success/10 flex items-center justify-center">
                  <Check className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">Last Backup</p>
                  <p className="text-xs text-muted-foreground">{formatDate(backupSettings.lastBackup)}</p>
                </div>
              </div>
            </div>

            {/* Auto Backup */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Database className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">Auto Backup</p>
                    <p className="text-xs text-muted-foreground">Automatically backup your data</p>
                  </div>
                </div>
                <Switch
                  checked={backupSettings.autoBackup}
                  onCheckedChange={(checked) => setBackupSettings({ ...backupSettings, autoBackup: checked })}
                />
              </div>

              {backupSettings.autoBackup && (
                <>
                  <Separator />
                  <div>
                    <Label className="text-xs text-muted-foreground">Backup Frequency</Label>
                    <div className="flex gap-2 mt-2">
                      {['daily', 'weekly', 'monthly'].map((freq) => (
                        <Button
                          key={freq}
                          variant={backupSettings.backupFrequency === freq ? 'default' : 'outline'}
                          size="sm"
                          className="flex-1 rounded-xl h-9 capitalize"
                          onClick={() => setBackupSettings({ ...backupSettings, backupFrequency: freq })}
                        >
                          {freq}
                        </Button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Cloud Sync */}
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Globe className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">Cloud Sync</p>
                    <p className="text-xs text-muted-foreground">Sync data across devices</p>
                  </div>
                </div>
                <Switch
                  checked={backupSettings.cloudSync}
                  onCheckedChange={(checked) => setBackupSettings({ ...backupSettings, cloudSync: checked })}
                />
              </div>
            </div>

            {/* Manual Actions */}
            <div className="space-y-3">
              <Button className="w-full h-12 rounded-xl gap-2">
                <Upload className="h-4 w-4" />
                Backup Now
              </Button>
              <Button variant="outline" className="w-full h-12 rounded-xl gap-2">
                <Download className="h-4 w-4" />
                Restore from Backup
              </Button>
            </div>

            {/* Warning */}
            <div className="bg-warning/5 border border-warning/20 rounded-2xl p-4">
              <p className="text-xs text-warning">
                Restoring from backup will replace all current data. Make sure to backup current data before restoring.
              </p>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  if (activeSection) {
    const section = settingsSections.find(s => s.id === activeSection)
    const Icon = section?.icon || Building2

    return (
      <div className="min-h-screen pb-24 animate-fade-in">
        {/* Header */}
        <div className="sticky top-0 z-40 bg-card/95 backdrop-blur-xl border-b border-border/50 px-4 py-3">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setActiveSection(null)} 
              className="h-9 w-9 rounded-xl"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h1 className="text-base font-semibold">{section?.title}</h1>
                <p className="text-xs text-muted-foreground">{section?.description}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4">
          {renderSectionContent()}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Header with Back Button */}
      {onBack && (
        <div className="flex items-center gap-3 mb-2">
          <Button variant="ghost" size="icon" onClick={onBack} className="h-9 w-9 rounded-xl">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-base font-semibold">Settings</h1>
            <p className="text-xs text-muted-foreground">Configure your lab</p>
          </div>
        </div>
      )}

      {/* Profile Card */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center gap-4">
          <Avatar className="h-14 w-14">
            <AvatarFallback className="bg-primary text-primary-foreground text-lg font-bold">
              PL
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h2 className="text-base font-semibold text-foreground">PathLab Pro</h2>
            <p className="text-xs text-muted-foreground">Main Laboratory Branch</p>
            <Badge variant="secondary" className="mt-1.5 rounded-full text-[10px]">
              Premium Plan
            </Badge>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="rounded-xl"
            onClick={() => setActiveSection('lab-profile')}
          >
            Edit
          </Button>
        </div>
      </div>

      {/* Quick Settings */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
        <h3 className="text-sm font-semibold text-foreground">Quick Settings</h3>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {theme === 'dark' ? (
              <Moon className="h-5 w-5 text-primary" />
            ) : (
              <Sun className="h-5 w-5 text-warning" />
            )}
            <div>
              <p className="text-sm font-medium text-foreground">Dark Mode</p>
              <p className="text-xs text-muted-foreground">Toggle theme</p>
            </div>
          </div>
          <Switch
            checked={theme === 'dark'}
            onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
          />
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium text-foreground">Push Notifications</p>
              <p className="text-xs text-muted-foreground">Critical alerts</p>
            </div>
          </div>
          <Switch defaultChecked />
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <QrCode className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-medium text-foreground">QR Verification</p>
              <p className="text-xs text-muted-foreground">Report authentication</p>
            </div>
          </div>
          <Switch defaultChecked />
        </div>
      </div>

      {/* Settings Sections */}
      <div className="space-y-2">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-1">
          Configuration
        </h3>
        <div className="bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden divide-y divide-border/50">
          {settingsSections.map((section) => {
            const Icon = section.icon
            return (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors"
              >
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 text-left">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-foreground">{section.title}</p>
                    {section.badge && (
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "rounded-full text-[10px] px-1.5",
                          section.badgeVariant === 'success' && "bg-success/10 text-success border-success/30",
                          section.badgeVariant === 'warning' && "bg-warning/10 text-warning border-warning/30",
                          section.badgeVariant === 'critical' && "bg-critical/10 text-critical border-critical/30"
                        )}
                      >
                        {section.badge}
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{section.description}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </button>
            )
          })}
        </div>
      </div>

      {/* Support & Help */}
      <div className="bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden divide-y divide-border/50">
        <button className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-info/10 flex items-center justify-center">
            <HelpCircle className="h-5 w-5 text-info" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-medium text-foreground">Help & Support</p>
            <p className="text-xs text-muted-foreground">FAQs & contact us</p>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </button>
        <button className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
            <Shield className="h-5 w-5 text-success" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-medium text-foreground">Privacy & Security</p>
            <p className="text-xs text-muted-foreground">Data protection settings</p>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      {/* Logout Button */}
      <Button 
        variant="outline" 
        className="w-full h-12 rounded-xl text-critical border-critical/30 hover:bg-critical/10 hover:text-critical"
        onClick={onLogout}
      >
        <LogOut className="h-5 w-5 mr-2" />
        Log Out
      </Button>

      {/* Version Info */}
      <p className="text-center text-xs text-muted-foreground">
        PathLab Pro v2.0.1 | Made with care
      </p>
    </div>
  )
}
