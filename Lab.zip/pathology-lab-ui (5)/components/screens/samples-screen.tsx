'use client'

import { useState } from 'react'
import { 
  Search, 
  Filter, 
  TestTube2, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  MoreVertical,
  Truck,
  User,
  Barcode,
  Eye,
  Printer,
  MessageCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'
import { SampleStatus, Priority } from '@/lib/types'

interface Sample {
  id: string
  barcode: string
  patientName: string
  uhid: string
  tests: string[]
  status: SampleStatus
  priority: Priority
  isHomeCollection: boolean
  collectedAt: Date
  doctor?: string
}

const mockSamples: Sample[] = [
  { id: '1', barcode: 'SMP2024001', patientName: 'Rahul Kumar', uhid: 'UHID00001234', tests: ['CBC', 'Lipid Profile'], status: 'Processing', priority: 'Normal', isHomeCollection: false, collectedAt: new Date(), doctor: 'Dr. Rajesh Sharma' },
  { id: '2', barcode: 'SMP2024002', patientName: 'Priya Singh', uhid: 'UHID00001235', tests: ['Thyroid Profile', 'HbA1c'], status: 'Pending', priority: 'Urgent', isHomeCollection: true, collectedAt: new Date() },
  { id: '3', barcode: 'SMP2024003', patientName: 'Amit Patel', uhid: 'UHID00001236', tests: ['LFT', 'KFT', 'CBC'], status: 'Completed', priority: 'Normal', isHomeCollection: false, collectedAt: new Date(), doctor: 'Dr. Priya Patel' },
  { id: '4', barcode: 'SMP2024004', patientName: 'Sunita Verma', uhid: 'UHID00001237', tests: ['Vitamin D', 'B12'], status: 'Approved', priority: 'Emergency', isHomeCollection: false, collectedAt: new Date() },
  { id: '5', barcode: 'SMP2024005', patientName: 'Vikram Mehta', uhid: 'UHID00001238', tests: ['CBC'], status: 'Delivered', priority: 'Normal', isHomeCollection: true, collectedAt: new Date(), doctor: 'Dr. Amit Kumar' },
  { id: '6', barcode: 'SMP2024006', patientName: 'Ananya Reddy', uhid: 'UHID00001239', tests: ['Urine Routine', 'Blood Sugar'], status: 'Collected', priority: 'Normal', isHomeCollection: false, collectedAt: new Date() },
]

const statusConfig: Record<SampleStatus, { color: string; bg: string; icon: React.ElementType }> = {
  'Pending': { color: 'text-warning', bg: 'bg-warning/10', icon: Clock },
  'Collected': { color: 'text-info', bg: 'bg-info/10', icon: TestTube2 },
  'Processing': { color: 'text-primary', bg: 'bg-primary/10', icon: TestTube2 },
  'Completed': { color: 'text-success', bg: 'bg-success/10', icon: CheckCircle },
  'Approved': { color: 'text-chart-4', bg: 'bg-chart-4/10', icon: CheckCircle },
  'Delivered': { color: 'text-muted-foreground', bg: 'bg-muted', icon: CheckCircle },
}

const priorityConfig: Record<Priority, { color: string; bg: string }> = {
  'Normal': { color: 'text-muted-foreground', bg: 'bg-muted' },
  'Urgent': { color: 'text-warning', bg: 'bg-warning/10' },
  'Emergency': { color: 'text-critical', bg: 'bg-critical/10' },
}

const filterTabs = ['All', 'Pending', 'Processing', 'Completed', 'Approved', 'Delivered']

export function SamplesScreen() {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState('All')

  const filteredSamples = mockSamples.filter((sample) => {
    const matchesSearch = 
      sample.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sample.barcode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sample.uhid.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = activeFilter === 'All' || sample.status === activeFilter
    return matchesSearch && matchesFilter
  })

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, barcode, or UHID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 pr-10 rounded-xl h-11 bg-card"
        />
        <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg">
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
        {filterTabs.map((tab) => (
          <Button
            key={tab}
            variant={activeFilter === tab ? 'default' : 'outline'}
            size="sm"
            className="rounded-full shrink-0 h-8"
            onClick={() => setActiveFilter(tab)}
          >
            {tab}
            {tab !== 'All' && (
              <Badge variant="secondary" className="ml-1.5 px-1.5 py-0 text-[10px] rounded-full">
                {mockSamples.filter((s) => s.status === tab).length}
              </Badge>
            )}
          </Button>
        ))}
      </div>

      {/* Samples List */}
      <div className="space-y-3">
        {filteredSamples.map((sample, index) => {
          const status = statusConfig[sample.status]
          const priority = priorityConfig[sample.priority]
          const StatusIcon = status.icon

          return (
            <div
              key={sample.id}
              className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", status.bg)}>
                    <StatusIcon className={cn("h-5 w-5", status.color)} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-foreground">{sample.patientName}</p>
                      {sample.isHomeCollection && (
                        <Truck className="h-3.5 w-3.5 text-info" />
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs text-muted-foreground font-mono">{sample.barcode}</span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">{sample.uhid}</span>
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 rounded-xl">
                    <DropdownMenuItem>
                      <Eye className="mr-2 h-4 w-4" /> View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Barcode className="mr-2 h-4 w-4" /> Print Barcode
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Printer className="mr-2 h-4 w-4" /> Print Report
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <MessageCircle className="mr-2 h-4 w-4" /> Send WhatsApp
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Tests */}
              <div className="flex flex-wrap gap-1.5 mb-3">
                {sample.tests.map((test) => (
                  <Badge key={test} variant="secondary" className="rounded-lg text-[10px] px-2 py-0.5">
                    {test}
                  </Badge>
                ))}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-border/50">
                <div className="flex items-center gap-3">
                  <Badge className={cn("rounded-full text-[10px] font-medium", status.bg, status.color)} variant="outline">
                    {sample.status}
                  </Badge>
                  {sample.priority !== 'Normal' && (
                    <Badge className={cn("rounded-full text-[10px] font-medium", priority.bg, priority.color)} variant="outline">
                      {sample.priority}
                    </Badge>
                  )}
                </div>
                {sample.doctor && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <User className="h-3 w-3" />
                    <span className="truncate max-w-[120px]">{sample.doctor}</span>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
