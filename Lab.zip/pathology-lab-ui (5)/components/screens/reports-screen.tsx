'use client'

import { useState } from 'react'
import { 
  Search, 
  Filter, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  MoreVertical,
  Download,
  Share2,
  Printer,
  Eye,
  MessageCircle,
  Mail,
  QrCode,
  Shield,
  TrendingUp,
  X,
  ChevronRight,
  Calendar,
  User,
  Phone,
  Beaker,
  CheckCircle2,
  XCircle,
  Send,
  Copy,
  ExternalLink,
  FileCheck,
  Loader2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'
import { ReportStatus } from '@/lib/types'

interface TestResult {
  name: string
  value: string
  unit: string
  normalRange: string
  status: 'normal' | 'low' | 'high' | 'critical'
}

interface Report {
  id: string
  reportId: string
  patientName: string
  patientPhone: string
  patientAge: string
  patientGender: string
  testName: string
  status: ReportStatus
  hasAbnormalValues: boolean
  hasCriticalValues: boolean
  approvedBy?: string
  createdAt: Date
  collectedAt: Date
  processedAt?: Date
  doctorName?: string
  results?: TestResult[]
}

const mockReports: Report[] = [
  { 
    id: '1', 
    reportId: 'RPT2024001', 
    patientName: 'Rahul Kumar', 
    patientPhone: '+91 98765 43210',
    patientAge: '35 Years',
    patientGender: 'Male',
    testName: 'Complete Blood Count', 
    status: 'Ready', 
    hasAbnormalValues: true, 
    hasCriticalValues: false, 
    createdAt: new Date(),
    collectedAt: new Date(Date.now() - 3600000),
    processedAt: new Date(),
    doctorName: 'Dr. Rajesh Sharma',
    results: [
      { name: 'Hemoglobin', value: '12.5', unit: 'g/dL', normalRange: '13.0 - 17.0', status: 'low' },
      { name: 'RBC Count', value: '4.8', unit: 'million/cumm', normalRange: '4.5 - 5.5', status: 'normal' },
      { name: 'WBC Count', value: '8500', unit: '/cumm', normalRange: '4000 - 11000', status: 'normal' },
      { name: 'Platelet Count', value: '2.5', unit: 'lakh/cumm', normalRange: '1.5 - 4.0', status: 'normal' },
      { name: 'PCV', value: '38', unit: '%', normalRange: '40 - 50', status: 'low' },
      { name: 'MCV', value: '82', unit: 'fL', normalRange: '80 - 100', status: 'normal' },
    ]
  },
  { 
    id: '2', 
    reportId: 'RPT2024002', 
    patientName: 'Priya Singh', 
    patientPhone: '+91 98765 43211',
    patientAge: '28 Years',
    patientGender: 'Female',
    testName: 'Thyroid Profile', 
    status: 'Pending', 
    hasAbnormalValues: false, 
    hasCriticalValues: false, 
    createdAt: new Date(),
    collectedAt: new Date(Date.now() - 7200000),
    doctorName: 'Dr. Priya Patel',
  },
  { 
    id: '3', 
    reportId: 'RPT2024003', 
    patientName: 'Amit Patel', 
    patientPhone: '+91 98765 43212',
    patientAge: '52 Years',
    patientGender: 'Male',
    testName: 'Blood Sugar Fasting', 
    status: 'Critical', 
    hasAbnormalValues: true, 
    hasCriticalValues: true, 
    createdAt: new Date(),
    collectedAt: new Date(Date.now() - 1800000),
    processedAt: new Date(),
    doctorName: 'Dr. Amit Kumar',
    results: [
      { name: 'Blood Glucose (Fasting)', value: '285', unit: 'mg/dL', normalRange: '70 - 100', status: 'critical' },
    ]
  },
  { 
    id: '4', 
    reportId: 'RPT2024004', 
    patientName: 'Sunita Verma', 
    patientPhone: '+91 98765 43213',
    patientAge: '45 Years',
    patientGender: 'Female',
    testName: 'Lipid Profile', 
    status: 'Approved', 
    hasAbnormalValues: false, 
    hasCriticalValues: false, 
    approvedBy: 'Dr. Meera Shah', 
    createdAt: new Date(),
    collectedAt: new Date(Date.now() - 14400000),
    processedAt: new Date(Date.now() - 7200000),
    doctorName: 'Dr. Sunita Verma',
    results: [
      { name: 'Total Cholesterol', value: '185', unit: 'mg/dL', normalRange: '< 200', status: 'normal' },
      { name: 'Triglycerides', value: '145', unit: 'mg/dL', normalRange: '< 150', status: 'normal' },
      { name: 'HDL Cholesterol', value: '55', unit: 'mg/dL', normalRange: '> 40', status: 'normal' },
      { name: 'LDL Cholesterol', value: '110', unit: 'mg/dL', normalRange: '< 130', status: 'normal' },
      { name: 'VLDL Cholesterol', value: '29', unit: 'mg/dL', normalRange: '< 40', status: 'normal' },
    ]
  },
  { 
    id: '5', 
    reportId: 'RPT2024005', 
    patientName: 'Vikram Mehta', 
    patientPhone: '+91 98765 43214',
    patientAge: '38 Years',
    patientGender: 'Male',
    testName: 'Liver Function Test', 
    status: 'Delivered', 
    hasAbnormalValues: true, 
    hasCriticalValues: false, 
    approvedBy: 'Dr. Meera Shah', 
    createdAt: new Date(),
    collectedAt: new Date(Date.now() - 28800000),
    processedAt: new Date(Date.now() - 21600000),
    doctorName: 'Dr. Arun Singh',
    results: [
      { name: 'SGPT (ALT)', value: '65', unit: 'U/L', normalRange: '7 - 56', status: 'high' },
      { name: 'SGOT (AST)', value: '42', unit: 'U/L', normalRange: '10 - 40', status: 'high' },
      { name: 'Alkaline Phosphatase', value: '85', unit: 'U/L', normalRange: '44 - 147', status: 'normal' },
      { name: 'Total Bilirubin', value: '0.9', unit: 'mg/dL', normalRange: '0.1 - 1.2', status: 'normal' },
      { name: 'Total Protein', value: '7.2', unit: 'g/dL', normalRange: '6.0 - 8.3', status: 'normal' },
    ]
  },
  { 
    id: '6', 
    reportId: 'RPT2024006', 
    patientName: 'Ananya Reddy', 
    patientPhone: '+91 98765 43215',
    patientAge: '32 Years',
    patientGender: 'Female',
    testName: 'HbA1c', 
    status: 'Processing', 
    hasAbnormalValues: false, 
    hasCriticalValues: false, 
    createdAt: new Date(),
    collectedAt: new Date(Date.now() - 5400000),
    doctorName: 'Dr. Rajesh Sharma',
  },
]

const statusConfig: Record<ReportStatus, { color: string; bg: string; icon: React.ElementType; label: string }> = {
  'Pending': { color: 'text-warning', bg: 'bg-warning/10', icon: Clock, label: 'Pending' },
  'Processing': { color: 'text-info', bg: 'bg-info/10', icon: Loader2, label: 'Processing' },
  'Ready': { color: 'text-primary', bg: 'bg-primary/10', icon: FileText, label: 'Ready' },
  'Approved': { color: 'text-success', bg: 'bg-success/10', icon: CheckCircle, label: 'Approved' },
  'Delivered': { color: 'text-muted-foreground', bg: 'bg-muted', icon: CheckCircle2, label: 'Delivered' },
  'Critical': { color: 'text-critical', bg: 'bg-critical/10', icon: AlertTriangle, label: 'Critical' },
}

const filterTabs = ['All', 'Pending', 'Ready', 'Approved', 'Critical', 'Delivered']

export function ReportsScreen() {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState('All')
  const [selectedReport, setSelectedReport] = useState<Report | null>(null)
  const [showPdfPreview, setShowPdfPreview] = useState(false)
  const [showWhatsAppShare, setShowWhatsAppShare] = useState(false)
  const [isSending, setIsSending] = useState(false)

  const filteredReports = mockReports.filter((report) => {
    const matchesSearch = 
      report.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.reportId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.testName.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = activeFilter === 'All' || report.status === activeFilter
    return matchesSearch && matchesFilter
  })

  const criticalCount = mockReports.filter((r) => r.status === 'Critical').length
  const pendingCount = mockReports.filter((r) => r.status === 'Pending' || r.status === 'Processing').length
  const completedCount = mockReports.filter((r) => r.status === 'Approved' || r.status === 'Delivered').length

  const handlePreview = (report: Report) => {
    setSelectedReport(report)
    setShowPdfPreview(true)
  }

  const handleWhatsAppShare = (report: Report) => {
    setSelectedReport(report)
    setShowWhatsAppShare(true)
  }

  const sendWhatsApp = async () => {
    setIsSending(true)
    await new Promise(resolve => setTimeout(resolve, 1500))
    setIsSending(false)
    setShowWhatsAppShare(false)
  }

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-card rounded-2xl border border-border/50 p-3 shadow-sm">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-7 w-7 rounded-lg bg-warning/10 flex items-center justify-center">
              <Clock className="h-3.5 w-3.5 text-warning" />
            </div>
          </div>
          <p className="text-xl font-bold text-foreground">{pendingCount}</p>
          <p className="text-[10px] text-muted-foreground">Pending</p>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-3 shadow-sm">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-7 w-7 rounded-lg bg-success/10 flex items-center justify-center">
              <CheckCircle className="h-3.5 w-3.5 text-success" />
            </div>
          </div>
          <p className="text-xl font-bold text-foreground">{completedCount}</p>
          <p className="text-[10px] text-muted-foreground">Completed</p>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-3 shadow-sm">
          <div className="flex items-center gap-2 mb-1">
            <div className="h-7 w-7 rounded-lg bg-critical/10 flex items-center justify-center">
              <AlertTriangle className="h-3.5 w-3.5 text-critical" />
            </div>
          </div>
          <p className="text-xl font-bold text-foreground">{criticalCount}</p>
          <p className="text-[10px] text-muted-foreground">Critical</p>
        </div>
      </div>

      {/* Critical Alert Banner */}
      {criticalCount > 0 && (
        <div className="bg-gradient-to-r from-critical/15 to-critical/5 border border-critical/20 rounded-2xl p-3 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-critical/20 flex items-center justify-center animate-pulse-ring">
            <AlertTriangle className="h-5 w-5 text-critical" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-critical">Critical Reports Alert</p>
            <p className="text-xs text-critical/80">{criticalCount} reports require immediate attention</p>
          </div>
          <Button 
            size="sm" 
            className="rounded-xl bg-critical hover:bg-critical/90 text-critical-foreground"
            onClick={() => setActiveFilter('Critical')}
          >
            View
          </Button>
        </div>
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by patient, report ID, or test..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 pr-10 rounded-xl h-11 bg-card border-border/50"
        />
        <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg">
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
        {filterTabs.map((tab) => {
          const count = tab === 'All' 
            ? mockReports.length 
            : mockReports.filter(r => r.status === tab).length
          return (
            <Button
              key={tab}
              variant={activeFilter === tab ? 'default' : 'outline'}
              size="sm"
              className={cn(
                "rounded-full shrink-0 h-8 gap-1.5",
                tab === 'Critical' && activeFilter === tab && "bg-critical hover:bg-critical/90"
              )}
              onClick={() => setActiveFilter(tab)}
            >
              {tab}
              <span className={cn(
                "px-1.5 py-0 rounded-full text-[10px]",
                activeFilter === tab ? "bg-white/20" : "bg-muted"
              )}>
                {count}
              </span>
            </Button>
          )
        })}
      </div>

      {/* Reports List */}
      <div className="space-y-3">
        {filteredReports.length === 0 ? (
          <div className="bg-card rounded-2xl border border-border/50 p-8 text-center">
            <div className="h-16 w-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">No Reports Found</p>
            <p className="text-xs text-muted-foreground">Try adjusting your search or filter criteria</p>
          </div>
        ) : (
          filteredReports.map((report, index) => {
            const status = statusConfig[report.status]
            const StatusIcon = status.icon

            return (
              <div
                key={report.id}
                className={cn(
                  "bg-card rounded-2xl border p-4 shadow-sm animate-slide-up transition-all",
                  report.status === 'Critical' 
                    ? "border-critical/30 bg-gradient-to-br from-critical/5 to-transparent" 
                    : "border-border/50 hover:border-primary/30 hover:shadow-md"
                )}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "h-11 w-11 rounded-xl flex items-center justify-center",
                      status.bg,
                      report.status === 'Processing' && "animate-pulse"
                    )}>
                      <StatusIcon className={cn("h-5 w-5", status.color, report.status === 'Processing' && "animate-spin")} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-foreground">{report.patientName}</p>
                        {report.hasCriticalValues && (
                          <span className="px-1.5 py-0.5 bg-critical/10 text-critical text-[9px] font-medium rounded-full">
                            CRITICAL
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-muted-foreground font-mono">{report.reportId}</span>
                        <span className="text-muted-foreground">|</span>
                        <span className="text-xs text-muted-foreground">{report.patientAge}, {report.patientGender}</span>
                      </div>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-52 rounded-xl">
                      <DropdownMenuItem onClick={() => handlePreview(report)}>
                        <Eye className="mr-2 h-4 w-4" /> Preview Report
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Download className="mr-2 h-4 w-4" /> Download PDF
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Printer className="mr-2 h-4 w-4" /> Print Report
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => handleWhatsAppShare(report)} className="text-success">
                        <MessageCircle className="mr-2 h-4 w-4" /> Share on WhatsApp
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Mail className="mr-2 h-4 w-4" /> Send via Email
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <QrCode className="mr-2 h-4 w-4" /> QR Verification
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Shield className="mr-2 h-4 w-4" /> Digital Signature
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {/* Test Info */}
                <div className="mb-3">
                  <div className="flex items-center gap-2">
                    <Beaker className="h-3.5 w-3.5 text-muted-foreground" />
                    <p className="text-sm font-medium text-foreground">{report.testName}</p>
                  </div>
                  {report.doctorName && (
                    <p className="text-xs text-muted-foreground mt-1">Referred by {report.doctorName}</p>
                  )}
                  <div className="flex items-center gap-3 mt-2">
                    {report.hasAbnormalValues && (
                      <div className="flex items-center gap-1 text-warning text-xs bg-warning/10 px-2 py-0.5 rounded-full">
                        <TrendingUp className="h-3 w-3" />
                        <span>Abnormal Values</span>
                      </div>
                    )}
                    {report.hasCriticalValues && (
                      <div className="flex items-center gap-1 text-critical text-xs bg-critical/10 px-2 py-0.5 rounded-full">
                        <AlertTriangle className="h-3 w-3" />
                        <span>Critical</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-3 border-t border-border/50">
                  <Badge className={cn("rounded-full text-[10px] font-medium border-0", status.bg, status.color)}>
                    {status.label}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {report.approvedBy ? (
                      <span>Approved by {report.approvedBy}</span>
                    ) : (
                      <span>{report.createdAt.toLocaleDateString()}</span>
                    )}
                  </div>
                </div>

                {/* Quick Actions for Ready/Approved Reports */}
                {(report.status === 'Ready' || report.status === 'Approved' || report.status === 'Delivered') && (
                  <div className="flex gap-2 mt-3 pt-3 border-t border-border/50">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 rounded-xl h-9 gap-1.5"
                      onClick={() => handlePreview(report)}
                    >
                      <Eye className="h-3.5 w-3.5" /> Preview
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 rounded-xl h-9 gap-1.5 text-success border-success/30 hover:bg-success/10"
                      onClick={() => handleWhatsAppShare(report)}
                    >
                      <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
                    </Button>
                    <Button size="sm" className="flex-1 rounded-xl h-9 gap-1.5">
                      <Download className="h-3.5 w-3.5" /> PDF
                    </Button>
                  </div>
                )}
              </div>
            )
          })
        )}
      </div>

      {/* PDF Preview Modal */}
      {showPdfPreview && selectedReport && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center animate-fade-in">
          <div 
            className="bg-card w-full max-w-lg rounded-t-3xl max-h-[90vh] overflow-hidden animate-slide-up"
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-card border-b border-border/50 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Report Preview</h3>
                  <p className="text-xs text-muted-foreground">{selectedReport.reportId}</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-9 w-9 rounded-xl"
                onClick={() => setShowPdfPreview(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            {/* Report Content */}
            <div className="overflow-y-auto max-h-[calc(90vh-180px)] p-4 space-y-4">
              {/* Lab Header */}
              <div className="text-center pb-4 border-b border-dashed border-border">
                <h2 className="text-lg font-bold text-primary">PathLab Pro Diagnostics</h2>
                <p className="text-xs text-muted-foreground">123 Healthcare Street, Medical District</p>
                <p className="text-xs text-muted-foreground">Phone: +91 98765 11111 | Email: reports@pathlab.com</p>
              </div>

              {/* Patient Details */}
              <div className="bg-muted/50 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{selectedReport.patientName}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{selectedReport.patientAge}, {selectedReport.patientGender}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Phone className="h-3 w-3" />
                    <span>{selectedReport.patientPhone}</span>
                  </div>
                  <span>Report ID: {selectedReport.reportId}</span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Collected: {selectedReport.collectedAt.toLocaleString()}</span>
                  <span>Reported: {selectedReport.processedAt?.toLocaleString() || 'Pending'}</span>
                </div>
                {selectedReport.doctorName && (
                  <div className="text-xs text-muted-foreground">
                    Referred By: {selectedReport.doctorName}
                  </div>
                )}
              </div>

              {/* Test Name */}
              <div className="flex items-center gap-2 py-2">
                <Beaker className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-foreground">{selectedReport.testName}</h3>
              </div>

              {/* Test Results */}
              {selectedReport.results && selectedReport.results.length > 0 ? (
                <div className="border border-border/50 rounded-xl overflow-hidden">
                  {/* Table Header */}
                  <div className="grid grid-cols-4 bg-muted/50 px-3 py-2 text-xs font-medium text-muted-foreground">
                    <span>Test</span>
                    <span className="text-center">Result</span>
                    <span className="text-center">Unit</span>
                    <span className="text-right">Normal Range</span>
                  </div>
                  {/* Table Rows */}
                  {selectedReport.results.map((result, idx) => (
                    <div 
                      key={idx}
                      className={cn(
                        "grid grid-cols-4 px-3 py-2.5 text-xs border-t border-border/30",
                        result.status === 'critical' && "bg-critical/5",
                        (result.status === 'high' || result.status === 'low') && "bg-warning/5"
                      )}
                    >
                      <span className="font-medium text-foreground">{result.name}</span>
                      <span className={cn(
                        "text-center font-semibold",
                        result.status === 'normal' && "text-foreground",
                        result.status === 'high' && "text-warning",
                        result.status === 'low' && "text-warning",
                        result.status === 'critical' && "text-critical"
                      )}>
                        {result.value}
                        {result.status === 'high' && ' ↑'}
                        {result.status === 'low' && ' ↓'}
                        {result.status === 'critical' && ' !!'}
                      </span>
                      <span className="text-center text-muted-foreground">{result.unit}</span>
                      <span className="text-right text-muted-foreground">{result.normalRange}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-muted/50 rounded-xl p-6 text-center">
                  <Loader2 className="h-8 w-8 text-muted-foreground mx-auto mb-2 animate-spin" />
                  <p className="text-sm text-muted-foreground">Results are being processed...</p>
                </div>
              )}

              {/* Interpretation */}
              {selectedReport.hasAbnormalValues && (
                <div className="bg-warning/10 border border-warning/20 rounded-xl p-3">
                  <h4 className="text-xs font-semibold text-warning mb-1">Interpretation</h4>
                  <p className="text-xs text-warning/80">
                    Some values are outside the normal range. Please consult with your physician for proper evaluation.
                  </p>
                </div>
              )}

              {/* Digital Signature */}
              {selectedReport.approvedBy && (
                <div className="flex items-center justify-between pt-4 border-t border-dashed border-border">
                  <div>
                    <p className="text-xs text-muted-foreground">Digitally Signed By</p>
                    <p className="text-sm font-medium text-foreground">{selectedReport.approvedBy}</p>
                    <p className="text-[10px] text-muted-foreground">MD, Pathology</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-success" />
                    <QrCode className="h-10 w-10 text-muted-foreground" />
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-card border-t border-border/50 p-4 flex gap-3">
              <Button variant="outline" className="flex-1 rounded-xl gap-2">
                <Printer className="h-4 w-4" /> Print
              </Button>
              <Button variant="outline" className="flex-1 rounded-xl gap-2">
                <Download className="h-4 w-4" /> Download
              </Button>
              <Button 
                className="flex-1 rounded-xl gap-2 bg-success hover:bg-success/90 text-success-foreground"
                onClick={() => {
                  setShowPdfPreview(false)
                  setShowWhatsAppShare(true)
                }}
              >
                <MessageCircle className="h-4 w-4" /> Share
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* WhatsApp Share Modal */}
      {showWhatsAppShare && selectedReport && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card w-full max-w-sm rounded-2xl overflow-hidden shadow-xl animate-slide-up">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-success to-success/80 p-4 flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-white/20 flex items-center justify-center">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-white">Share on WhatsApp</h3>
                <p className="text-xs text-white/80">Send report to patient</p>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-9 w-9 rounded-xl text-white hover:bg-white/20"
                onClick={() => setShowWhatsAppShare(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            {/* Content */}
            <div className="p-4 space-y-4">
              {/* Patient Info */}
              <div className="bg-muted/50 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{selectedReport.patientName}</span>
                  <Badge variant="outline" className="rounded-full text-[10px]">
                    {selectedReport.reportId}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="h-3.5 w-3.5" />
                  <span>{selectedReport.patientPhone}</span>
                </div>
              </div>

              {/* Message Preview */}
              <div className="bg-success/5 border border-success/20 rounded-xl p-3">
                <p className="text-xs text-muted-foreground mb-2">Message Preview:</p>
                <div className="bg-card rounded-lg p-3 text-sm">
                  <p className="text-foreground">
                    Dear {selectedReport.patientName.split(' ')[0]},
                  </p>
                  <p className="text-foreground mt-2">
                    Your {selectedReport.testName} report is ready. Report ID: {selectedReport.reportId}
                  </p>
                  <p className="text-primary mt-2">
                    Download: https://pathlab.pro/r/{selectedReport.reportId}
                  </p>
                  <p className="text-muted-foreground mt-2 text-xs">
                    - PathLab Pro Diagnostics
                  </p>
                </div>
              </div>

              {/* Options */}
              <div className="space-y-2">
                <label className="flex items-center gap-3 p-3 bg-muted/50 rounded-xl cursor-pointer hover:bg-muted transition-colors">
                  <input type="checkbox" className="h-4 w-4 rounded border-border text-success focus:ring-success" defaultChecked />
                  <div className="flex-1">
                    <p className="text-sm font-medium">Attach PDF Report</p>
                    <p className="text-xs text-muted-foreground">Include full report as attachment</p>
                  </div>
                </label>
                <label className="flex items-center gap-3 p-3 bg-muted/50 rounded-xl cursor-pointer hover:bg-muted transition-colors">
                  <input type="checkbox" className="h-4 w-4 rounded border-border text-success focus:ring-success" defaultChecked />
                  <div className="flex-1">
                    <p className="text-sm font-medium">Include Download Link</p>
                    <p className="text-xs text-muted-foreground">Add secure download URL</p>
                  </div>
                </label>
              </div>

              {/* Quick Actions */}
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 rounded-xl gap-1.5">
                  <Copy className="h-3.5 w-3.5" /> Copy Link
                </Button>
                <Button variant="outline" size="sm" className="flex-1 rounded-xl gap-1.5">
                  <ExternalLink className="h-3.5 w-3.5" /> Open Chat
                </Button>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 pt-0 flex gap-3">
              <Button 
                variant="outline" 
                className="flex-1 rounded-xl"
                onClick={() => setShowWhatsAppShare(false)}
              >
                Cancel
              </Button>
              <Button 
                className="flex-1 rounded-xl gap-2 bg-success hover:bg-success/90 text-success-foreground"
                onClick={sendWhatsApp}
                disabled={isSending}
              >
                {isSending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Sending...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" /> Send Now
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
