'use client'

import { useState, useEffect } from 'react'
import { 
  Eye, 
  EyeOff, 
  Mail, 
  Lock, 
  Phone, 
  User, 
  Building2,
  ChevronRight,
  ArrowLeft,
  Check,
  Shield,
  Fingerprint,
  Sparkles
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

type AuthView = 'login' | 'signup' | 'forgot-password' | 'otp-verify'

interface AuthScreenProps {
  onLoginSuccess: () => void
}

export function AuthScreen({ onLoginSuccess }: AuthScreenProps) {
  const [view, setView] = useState<AuthView>('login')
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [loginMethod, setLoginMethod] = useState<'email' | 'phone'>('email')
  
  // Form states
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [labName, setLabName] = useState('')
  const [otp, setOtp] = useState(['', '', '', '', '', ''])

  // Animation states
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    setShowContent(true)
  }, [])

  const handleLogin = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      onLoginSuccess()
    }, 1500)
  }

  const handleSignup = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      setView('otp-verify')
    }, 1500)
  }

  const handleForgotPassword = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      setView('otp-verify')
    }, 1500)
  }

  const handleOtpVerify = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
      onLoginSuccess()
    }, 1500)
  }

  const handleOtpChange = (index: number, value: string) => {
    if (value.length <= 1) {
      const newOtp = [...otp]
      newOtp[index] = value
      setOtp(newOtp)
      
      // Auto focus next input
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`)
        nextInput?.focus()
      }
    }
  }

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`)
      prevInput?.focus()
    }
  }

  const renderLoginView = () => (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-foreground mb-2">Welcome Back</h1>
        <p className="text-muted-foreground text-sm">Sign in to continue to PathLab Pro</p>
      </div>

      {/* Login Method Toggle */}
      <div className="flex bg-muted/50 rounded-xl p-1">
        <button
          className={cn(
            "flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
            loginMethod === 'email' 
              ? "bg-card shadow-sm text-foreground" 
              : "text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setLoginMethod('email')}
        >
          <Mail className="h-4 w-4 inline-block mr-2" />
          Email
        </button>
        <button
          className={cn(
            "flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
            loginMethod === 'phone' 
              ? "bg-card shadow-sm text-foreground" 
              : "text-muted-foreground hover:text-foreground"
          )}
          onClick={() => setLoginMethod('phone')}
        >
          <Phone className="h-4 w-4 inline-block mr-2" />
          Phone
        </button>
      </div>

      {/* Form */}
      <div className="space-y-4">
        {loginMethod === 'email' ? (
          <div className="space-y-2">
            <label className="text-xs font-medium text-muted-foreground">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-11 h-12 rounded-xl bg-muted/30 border-border/50"
              />
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <label className="text-xs font-medium text-muted-foreground">Phone Number</label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <span className="text-sm text-muted-foreground">+91</span>
                <div className="h-4 w-px bg-border/50" />
              </div>
              <Input
                type="tel"
                placeholder="Enter phone number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="pl-16 h-12 rounded-xl bg-muted/30 border-border/50"
              />
            </div>
          </div>
        )}

        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Password</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-11 pr-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
            <button
              type="button"
              className="absolute right-4 top-1/2 -translate-y-1/2"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4 text-muted-foreground" />
              ) : (
                <Eye className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
          </div>
        </div>

        {/* Remember Me & Forgot Password */}
        <div className="flex items-center justify-between">
          <button
            className="flex items-center gap-2"
            onClick={() => setRememberMe(!rememberMe)}
          >
            <div className={cn(
              "h-5 w-5 rounded-md border-2 flex items-center justify-center transition-all",
              rememberMe 
                ? "bg-primary border-primary" 
                : "border-border/50"
            )}>
              {rememberMe && <Check className="h-3 w-3 text-primary-foreground" />}
            </div>
            <span className="text-sm text-muted-foreground">Remember me</span>
          </button>
          <button
            className="text-sm text-primary font-medium hover:underline"
            onClick={() => setView('forgot-password')}
          >
            Forgot Password?
          </button>
        </div>

        {/* Login Button */}
        <Button
          className="w-full h-12 rounded-xl text-base font-semibold"
          onClick={handleLogin}
          disabled={isLoading}
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Signing in...
            </div>
          ) : (
            <>
              Sign In
              <ChevronRight className="h-5 w-5 ml-2" />
            </>
          )}
        </Button>

        {/* Divider */}
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border/50" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">or continue with</span>
          </div>
        </div>

        {/* Biometric Login */}
        <div className="flex gap-3">
          <Button variant="outline" className="flex-1 h-12 rounded-xl">
            <Fingerprint className="h-5 w-5 mr-2 text-primary" />
            Biometric
          </Button>
          <Button variant="outline" className="flex-1 h-12 rounded-xl">
            <Shield className="h-5 w-5 mr-2 text-primary" />
            Face ID
          </Button>
        </div>
      </div>

      {/* Sign Up Link */}
      <p className="text-center text-sm text-muted-foreground">
        {"Don't have an account? "}
        <button
          className="text-primary font-semibold hover:underline"
          onClick={() => setView('signup')}
        >
          Sign Up
        </button>
      </p>
    </div>
  )

  const renderSignupView = () => (
    <div className="space-y-6 animate-fade-in">
      {/* Back Button */}
      <button
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        onClick={() => setView('login')}
      >
        <ArrowLeft className="h-4 w-4" />
        <span className="text-sm">Back to Login</span>
      </button>

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground mb-2">Create Account</h1>
        <p className="text-muted-foreground text-sm">Set up your PathLab Pro account</p>
      </div>

      {/* Form */}
      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Full Name</label>
          <div className="relative">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Enter your full name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="pl-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Laboratory Name</label>
          <div className="relative">
            <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Enter lab name"
              value={labName}
              onChange={(e) => setLabName(e.target.value)}
              className="pl-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Email Address</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Phone Number</label>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <span className="text-sm text-muted-foreground">+91</span>
              <div className="h-4 w-px bg-border/50" />
            </div>
            <Input
              type="tel"
              placeholder="Enter phone number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="pl-16 h-12 rounded-xl bg-muted/30 border-border/50"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Password</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="Create a password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-11 pr-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
            <button
              type="button"
              className="absolute right-4 top-1/2 -translate-y-1/2"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4 text-muted-foreground" />
              ) : (
                <Eye className="h-4 w-4 text-muted-foreground" />
              )}
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Confirm Password</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="Confirm your password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="pl-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
          </div>
        </div>

        {/* Terms */}
        <p className="text-xs text-muted-foreground text-center">
          By signing up, you agree to our{' '}
          <span className="text-primary hover:underline cursor-pointer">Terms of Service</span>
          {' '}and{' '}
          <span className="text-primary hover:underline cursor-pointer">Privacy Policy</span>
        </p>

        {/* Sign Up Button */}
        <Button
          className="w-full h-12 rounded-xl text-base font-semibold"
          onClick={handleSignup}
          disabled={isLoading}
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Creating account...
            </div>
          ) : (
            <>
              Create Account
              <ChevronRight className="h-5 w-5 ml-2" />
            </>
          )}
        </Button>
      </div>

      {/* Login Link */}
      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{' '}
        <button
          className="text-primary font-semibold hover:underline"
          onClick={() => setView('login')}
        >
          Sign In
        </button>
      </p>
    </div>
  )

  const renderForgotPasswordView = () => (
    <div className="space-y-6 animate-fade-in">
      {/* Back Button */}
      <button
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        onClick={() => setView('login')}
      >
        <ArrowLeft className="h-4 w-4" />
        <span className="text-sm">Back to Login</span>
      </button>

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground mb-2">Forgot Password?</h1>
        <p className="text-muted-foreground text-sm">{"Enter your email and we'll send you a reset link"}</p>
      </div>

      {/* Illustration */}
      <div className="flex justify-center py-4">
        <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
          <Lock className="h-12 w-12 text-primary" />
        </div>
      </div>

      {/* Form */}
      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground">Email Address</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-11 h-12 rounded-xl bg-muted/30 border-border/50"
            />
          </div>
        </div>

        <Button
          className="w-full h-12 rounded-xl text-base font-semibold"
          onClick={handleForgotPassword}
          disabled={isLoading}
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Sending...
            </div>
          ) : (
            <>
              Send Reset Link
              <ChevronRight className="h-5 w-5 ml-2" />
            </>
          )}
        </Button>
      </div>
    </div>
  )

  const renderOtpVerifyView = () => (
    <div className="space-y-6 animate-fade-in">
      {/* Back Button */}
      <button
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        onClick={() => setView('login')}
      >
        <ArrowLeft className="h-4 w-4" />
        <span className="text-sm">Back</span>
      </button>

      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-foreground mb-2">Verify OTP</h1>
        <p className="text-muted-foreground text-sm">
          {"We've sent a 6-digit code to"}
          <br />
          <span className="text-foreground font-medium">{email || phone}</span>
        </p>
      </div>

      {/* OTP Illustration */}
      <div className="flex justify-center py-4">
        <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
          <Shield className="h-10 w-10 text-primary" />
        </div>
      </div>

      {/* OTP Input */}
      <div className="flex justify-center gap-2">
        {otp.map((digit, index) => (
          <Input
            key={index}
            id={`otp-${index}`}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={digit}
            onChange={(e) => handleOtpChange(index, e.target.value)}
            onKeyDown={(e) => handleOtpKeyDown(index, e)}
            className={cn(
              "w-12 h-14 text-center text-xl font-bold rounded-xl bg-muted/30 border-2 transition-all",
              digit ? "border-primary" : "border-border/50"
            )}
          />
        ))}
      </div>

      {/* Resend */}
      <p className="text-center text-sm text-muted-foreground">
        {"Didn't receive the code? "}
        <button className="text-primary font-semibold hover:underline">
          Resend OTP
        </button>
      </p>

      {/* Verify Button */}
      <Button
        className="w-full h-12 rounded-xl text-base font-semibold"
        onClick={handleOtpVerify}
        disabled={isLoading || otp.some(d => !d)}
      >
        {isLoading ? (
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            Verifying...
          </div>
        ) : (
          <>
            Verify & Continue
            <ChevronRight className="h-5 w-5 ml-2" />
          </>
        )}
      </Button>
    </div>
  )

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top Section - Branding */}
      <div className={cn(
        "relative pt-12 pb-8 px-6 bg-gradient-to-br from-primary via-primary to-primary/80 text-white transition-all duration-500",
        showContent ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
      )}>
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-4 right-4 h-32 w-32 rounded-full border-4 border-white" />
          <div className="absolute bottom-0 left-0 h-24 w-24 rounded-full border-4 border-white translate-x-[-50%] translate-y-[50%]" />
        </div>

        {/* Logo & Brand */}
        <div className="relative flex items-center gap-3 mb-4">
          <div className="h-14 w-14 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Sparkles className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">PathLab Pro</h1>
            <p className="text-white/80 text-sm">Laboratory Management System</p>
          </div>
        </div>

        {/* Features */}
        <div className="relative flex gap-4 mt-6">
          <div className="flex items-center gap-2 text-white/90 text-xs">
            <Check className="h-4 w-4" />
            <span>Enterprise Ready</span>
          </div>
          <div className="flex items-center gap-2 text-white/90 text-xs">
            <Check className="h-4 w-4" />
            <span>NABL Compliant</span>
          </div>
          <div className="flex items-center gap-2 text-white/90 text-xs">
            <Check className="h-4 w-4" />
            <span>24/7 Support</span>
          </div>
        </div>
      </div>

      {/* Bottom Section - Auth Forms */}
      <div className={cn(
        "flex-1 bg-background rounded-t-3xl -mt-4 relative z-10 px-6 pt-8 pb-6 transition-all duration-500 delay-200",
        showContent ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      )}>
        {view === 'login' && renderLoginView()}
        {view === 'signup' && renderSignupView()}
        {view === 'forgot-password' && renderForgotPasswordView()}
        {view === 'otp-verify' && renderOtpVerifyView()}
      </div>
    </div>
  )
}
