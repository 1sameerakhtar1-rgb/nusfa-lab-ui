'use client'

import { useState } from 'react'
import { 
  IndianRupee, 
  TrendingUp, 
  Users, 
  TestTube2,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Clock
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  ResponsiveContainer, 
  Tooltip,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts'
import { revenueChartData, testCategoryData, hourlyData, mockDoctors, mockCollectionCenters } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))']

const timeFilters = ['Today', 'Week', 'Month', 'Year']

export function AnalyticsScreen() {
  const [activeTimeFilter, setActiveTimeFilter] = useState('Month')

  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Time Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
        {timeFilters.map((filter) => (
          <Button
            key={filter}
            variant={activeTimeFilter === filter ? 'default' : 'outline'}
            size="sm"
            className="rounded-full shrink-0 h-8"
            onClick={() => setActiveTimeFilter(filter)}
          >
            {filter}
          </Button>
        ))}
      </div>

      {/* Revenue Summary */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Total Revenue</p>
            <p className="text-2xl font-bold text-foreground mt-1">Rs. 12,45,000</p>
            <div className="flex items-center gap-1 mt-1">
              <Badge className="bg-success/10 text-success text-[10px] rounded-full px-1.5">
                <ArrowUpRight className="h-3 w-3 mr-0.5" />
                12.5%
              </Badge>
              <span className="text-[10px] text-muted-foreground">vs last month</span>
            </div>
          </div>
          <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <IndianRupee className="h-5 w-5 text-primary" />
          </div>
        </div>

        {/* Mini Stats */}
        <div className="grid grid-cols-3 gap-3 pt-4 border-t border-border/50">
          <div className="text-center">
            <p className="text-lg font-bold text-foreground">342</p>
            <p className="text-[10px] text-muted-foreground">Samples</p>
          </div>
          <div className="text-center border-x border-border/50">
            <p className="text-lg font-bold text-foreground">890</p>
            <p className="text-[10px] text-muted-foreground">Patients</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold text-foreground">1,250</p>
            <p className="text-[10px] text-muted-foreground">Tests</p>
          </div>
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground">Revenue Growth</h3>
          <Badge variant="outline" className="rounded-full text-[10px]">
            <TrendingUp className="h-3 w-3 mr-1 text-success" />
            +12.5%
          </Badge>
        </div>
        <div className="h-[200px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={revenueChartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="revenueGradient2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="month" 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                tickFormatter={(value) => `${(value / 100000).toFixed(0)}L`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-popover border border-border rounded-lg p-2 shadow-lg">
                        <p className="text-xs font-medium text-foreground">{label}</p>
                        <p className="text-sm font-bold text-primary">
                          Rs. {(payload[0].value as number).toLocaleString()}
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Area
                type="monotone"
                dataKey="revenue"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                fill="url(#revenueGradient2)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Peak Hours */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            Peak Business Hours
          </h3>
        </div>
        <div className="h-[160px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourlyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <XAxis 
                dataKey="hour" 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-popover border border-border rounded-lg p-2 shadow-lg">
                        <p className="text-xs font-medium text-foreground">{label}</p>
                        <p className="text-sm font-bold text-primary">
                          {payload[0].value} samples
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Bar 
                dataKey="samples" 
                fill="hsl(var(--primary))" 
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Test Categories Distribution */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <h3 className="text-sm font-semibold text-foreground mb-4">Test Categories</h3>
        <div className="flex items-center gap-4">
          <div className="h-[140px] w-[140px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={testCategoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={35}
                  outerRadius={60}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {testCategoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex-1 space-y-2">
            {testCategoryData.map((category, index) => (
              <div key={category.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div 
                    className="h-2.5 w-2.5 rounded-full" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-xs text-foreground">{category.name}</span>
                </div>
                <span className="text-xs font-semibold text-foreground">{category.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Referral Doctors */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            Top Referral Doctors
          </h3>
          <button className="text-xs text-primary font-medium hover:underline">View All</button>
        </div>
        <div className="space-y-3">
          {mockDoctors.slice(0, 3).map((doctor, index) => (
            <div key={doctor.id} className="flex items-center gap-3">
              <span className="text-xs font-bold text-muted-foreground w-4">{index + 1}</span>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{doctor.name}</p>
                <p className="text-[10px] text-muted-foreground">{doctor.totalReferrals} referrals</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-success">Rs. {(doctor.totalRevenue / 1000).toFixed(0)}K</p>
                <Badge variant="outline" className="rounded-full text-[10px] mt-0.5">
                  {doctor.commission}% comm
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Collection Center Performance */}
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <TestTube2 className="h-4 w-4 text-primary" />
            Collection Centers
          </h3>
          <button className="text-xs text-primary font-medium hover:underline">View All</button>
        </div>
        <div className="space-y-3">
          {mockCollectionCenters.slice(0, 3).map((center) => (
            <div key={center.id} className="flex items-center gap-3">
              <div className={cn(
                "h-10 w-10 rounded-xl flex items-center justify-center text-sm font-bold",
                center.performance >= 90 
                  ? "bg-success/10 text-success" 
                  : center.performance >= 80 
                    ? "bg-warning/10 text-warning"
                    : "bg-critical/10 text-critical"
              )}>
                {center.performance}%
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{center.name}</p>
                <p className="text-[10px] text-muted-foreground">{center.totalCollections} collections</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-primary">Rs. {(center.revenue / 1000).toFixed(0)}K</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-success/10 border border-success/20 rounded-2xl p-4">
          <p className="text-xs text-success font-medium">Collections Today</p>
          <p className="text-xl font-bold text-success mt-1">Rs. 45,600</p>
          <div className="flex items-center gap-1 mt-1">
            <ArrowUpRight className="h-3 w-3 text-success" />
            <span className="text-[10px] text-success">+8.2% vs yesterday</span>
          </div>
        </div>
        <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4">
          <p className="text-xs text-primary font-medium">Avg. Per Patient</p>
          <p className="text-xl font-bold text-primary mt-1">Rs. 1,420</p>
          <div className="flex items-center gap-1 mt-1">
            <ArrowUpRight className="h-3 w-3 text-primary" />
            <span className="text-[10px] text-primary">+3.5% growth</span>
          </div>
        </div>
      </div>
    </div>
  )
}
