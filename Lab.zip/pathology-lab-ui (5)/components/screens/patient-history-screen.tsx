'use client'

import { useState } from 'react'
import { 
  Search, 
  ArrowLeft,
  Calendar,
  Download,
  MessageCircle,
  Phone,
  Mail,
  ChevronRight,
  FileText,
  IndianRupee,
  TestTube,
  Clock,
  CheckCircle,
  AlertCircle,
  Filter,
  User,
  MapPin,
  X,
  Eye,
  Printer,
  Share2,
  CreditCard,
  Receipt
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'

interface PatientRecord {
  id: string
  uhid: string
  name: string
  phone: string
  email: string
  gender: string
  age: number
  address: string
  city: string
  totalVisits: number
  totalSpent: number
  lastVisit: Date
}

interface TestHistory {
  id: string
  date: Date
  tests: string[]
  status: 'Completed' | 'Pending' | 'Processing'
  totalAmount: number
  reportId?: string
}

interface PaymentHistory {
  id: string
  date: Date
  invoiceNumber: string
  amount: number
  method: string
  status: 'Paid' | 'Partial' | 'Pending'
}

const mockPatients: PatientRecord[] = [
  { id: '1', uhid: 'UHID2024001', name: 'Rahul Kumar', phone: '+91 98765 43210', email: 'rahul.kumar@email.com', gender: 'Male', age: 35, address: '123 Main Street', city: 'Mumbai', totalVisits: 12, totalSpent: 18500, lastVisit: new Date(Date.now() - 86400000) },
  { id: '2', uhid: 'UHID2024002', name: 'Priya Singh', phone: '+91 87654 32109', email: 'priya.singh@email.com', gender: 'Female', age: 28, address: '456 Park Avenue', city: 'Delhi', totalVisits: 8, totalSpent: 12800, lastVisit: new Date(Date.now() - 172800000) },
  { id: '3', uhid: 'UHID2024003', name: 'Amit Patel', phone: '+91 76543 21098', email: 'amit.patel@email.com', gender: 'Male', age: 45, address: '789 Lake View', city: 'Ahmedabad', totalVisits: 15, totalSpent: 24500, lastVisit: new Date(Date.now() - 259200000) },
  { id: '4', uhid: 'UHID2024004', name: 'Sunita Verma', phone: '+91 65432 10987', email: 'sunita.verma@email.com', gender: 'Female', age: 52, address: '321 Green Park', city: 'Pune', totalVisits: 20, totalSpent: 32000, lastVisit: new Date(Date.now() - 345600000) },
]

const mockTestHistory: TestHistory[] = [
  { id: '1', date: new Date(Date.now() - 86400000), tests: ['Complete Blood Count', 'Lipid Profile', 'HbA1c'], status: 'Completed', totalAmount: 1450, reportId: 'RPT001' },
  { id: '2', date: new Date(Date.now() - 604800000), tests: ['Thyroid Profile'], status: 'Completed', totalAmount: 950, reportId: 'RPT002' },
  { id: '3', date: new Date(Date.now() - 1209600000), tests: ['Vitamin D', 'Vitamin B12'], status: 'Completed', totalAmount: 2000, reportId: 'RPT003' },
  { id: '4', date: new Date(Date.now() - 2419200000), tests: ['Liver Function Test', 'Kidney Function Test'], status: 'Completed', totalAmount: 1550, reportId: 'RPT004' },
  { id: '5', date: new Date(Date.now() - 3628800000), tests: ['Complete Blood Count', 'ESR'], status: 'Completed', totalAmount: 450, reportId: 'RPT005' },
]

const mockPaymentHistory: PaymentHistory[] = [
  { id: '1', date: new Date(Date.now() - 86400000), invoiceNumber: 'INV2024089', amount: 1450, method: 'UPI', status: 'Paid' },
  { id: '2', date: new Date(Date.now() - 604800000), invoiceNumber: 'INV2024076', amount: 950, method: 'Cash', status: 'Paid' },
  { id: '3', date: new Date(Date.now() - 1209600000), invoiceNumber: 'INV2024065', amount: 2000, method: 'Card', status: 'Paid' },
  { id: '4', date: new Date(Date.now() - 2419200000), invoiceNumber: 'INV2024054', amount: 1550, method: 'UPI', status: 'Paid' },
  { id: '5', date: new Date(Date.now() - 3628800000), invoiceNumber: 'INV2024043', amount: 450, method: 'Cash', status: 'Paid' },
]

interface PatientHistoryScreenProps {
  onBack?: () => void
}

export function PatientHistoryScreen({ onBack }: PatientHistoryScreenProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedPatient, setSelectedPatient] = useState<PatientRecord | null>(null)
  const [activeTab, setActiveTab] = useState<'tests' | 'payments'>('tests')
  const [showReportModal, setShowReportModal] = useState(false)
  const [selectedReport, setSelectedReport] = useState<TestHistory | null>(null)
  const [dateFilter, setDateFilter] = useState('all')

  const filteredPatients = mockPatients.filter((patient) =>
    patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.uhid.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.phone.includes(searchQuery)
  )

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-IN', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric' 
    })
  }

  const handleViewReport = (test: TestHistory) => {
    setSelectedReport(test)
    setShowReportModal(true)
  }

  const handleWhatsAppShare = (test: TestHistory) => {
    const message = `Your test report for ${test.tests.join(', ')} dated ${formatDate(test.date)} is ready. Download from PathLab Pro app.`
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank')
  }

  if (selectedPatient) {
    return (
      <div className="min-h-screen pb-24 animate-fade-in">
        {/* Header */}
        <div className="sticky top-0 z-40 bg-card/95 backdrop-blur-xl border-b border-border/50 px-4 py-3">
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setSelectedPatient(null)} 
              className="h-9 w-9 rounded-xl"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-base font-semibold">Patient History</h1>
              <p className="text-xs text-muted-foreground">{selectedPatient.uhid}</p>
            </div>
            <Button variant="outline" size="sm" className="rounded-xl h-9 gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Patient Profile Card */}
          <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
            <div className="flex items-start gap-4">
              <Avatar className="h-16 w-16">
                <AvatarFallback className="bg-primary/10 text-primary text-xl font-bold">
                  {selectedPatient.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="text-lg font-semibold text-foreground">{selectedPatient.name}</h2>
                <p className="text-sm text-muted-foreground">{selectedPatient.gender}, {selectedPatient.age} years</p>
                <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                  <MapPin className="h-3 w-3" />
                  <span>{selectedPatient.city}</span>
                </div>
              </div>
            </div>

            <Separator className="my-4" />

            {/* Contact Info */}
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" size="sm" className="h-10 rounded-xl justify-start gap-2">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-xs truncate">{selectedPatient.phone}</span>
              </Button>
              <Button variant="outline" size="sm" className="h-10 rounded-xl justify-start gap-2">
                <Mail className="h-4 w-4 text-primary" />
                <span className="text-xs truncate">Email</span>
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-2 mt-4">
              <div className="bg-muted/30 rounded-xl p-3 text-center">
                <p className="text-lg font-bold text-primary">{selectedPatient.totalVisits}</p>
                <p className="text-[10px] text-muted-foreground">Total Visits</p>
              </div>
              <div className="bg-muted/30 rounded-xl p-3 text-center">
                <p className="text-lg font-bold text-success">Rs.{(selectedPatient.totalSpent / 1000).toFixed(1)}k</p>
                <p className="text-[10px] text-muted-foreground">Total Spent</p>
              </div>
              <div className="bg-muted/30 rounded-xl p-3 text-center">
                <p className="text-xs font-semibold text-foreground">{formatDate(selectedPatient.lastVisit)}</p>
                <p className="text-[10px] text-muted-foreground">Last Visit</p>
              </div>
            </div>
          </div>

          {/* Date Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
            {['all', '7days', '30days', '90days', '1year'].map((filter) => (
              <Button
                key={filter}
                variant={dateFilter === filter ? 'default' : 'outline'}
                size="sm"
                className="rounded-full shrink-0 h-8"
                onClick={() => setDateFilter(filter)}
              >
                {filter === 'all' ? 'All Time' : 
                 filter === '7days' ? 'Last 7 Days' :
                 filter === '30days' ? 'Last 30 Days' :
                 filter === '90days' ? 'Last 90 Days' : 'Last Year'}
              </Button>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-2 bg-muted/30 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('tests')}
              className={cn(
                "flex-1 py-2.5 text-sm font-medium rounded-lg transition-all",
                activeTab === 'tests' 
                  ? "bg-card shadow-sm text-foreground" 
                  : "text-muted-foreground"
              )}
            >
              <TestTube className="h-4 w-4 inline mr-2" />
              Test History
            </button>
            <button
              onClick={() => setActiveTab('payments')}
              className={cn(
                "flex-1 py-2.5 text-sm font-medium rounded-lg transition-all",
                activeTab === 'payments' 
                  ? "bg-card shadow-sm text-foreground" 
                  : "text-muted-foreground"
              )}
            >
              <CreditCard className="h-4 w-4 inline mr-2" />
              Payment History
            </button>
          </div>

          {/* Test History */}
          {activeTab === 'tests' && (
            <div className="space-y-3">
              {mockTestHistory.map((test, index) => (
                <div
                  key={test.id}
                  className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm animate-slide-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "h-10 w-10 rounded-xl flex items-center justify-center",
                        test.status === 'Completed' ? "bg-success/10" : "bg-warning/10"
                      )}>
                        <TestTube className={cn(
                          "h-5 w-5",
                          test.status === 'Completed' ? "text-success" : "text-warning"
                        )} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-3 w-3 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{formatDate(test.date)}</span>
                        </div>
                        <p className="text-sm font-semibold text-foreground mt-0.5">
                          {test.tests.length} Test{test.tests.length > 1 ? 's' : ''}
                        </p>
                      </div>
                    </div>
                    <Badge 
                      className={cn(
                        "rounded-full text-[10px] border-0",
                        test.status === 'Completed' ? "bg-success/10 text-success" : "bg-warning/10 text-warning"
                      )}
                    >
                      {test.status === 'Completed' && <CheckCircle className="h-3 w-3 mr-1" />}
                      {test.status}
                    </Badge>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {test.tests.map((t) => (
                      <Badge key={t} variant="secondary" className="rounded-lg text-[10px] px-2 py-0.5 bg-muted/50">
                        {t}
                      </Badge>
                    ))}
                  </div>

                  <Separator className="my-3" />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-sm font-semibold text-foreground">
                      <IndianRupee className="h-4 w-4" />
                      {test.totalAmount.toLocaleString()}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 rounded-lg gap-1.5"
                        onClick={() => handleViewReport(test)}
                      >
                        <Eye className="h-4 w-4" />
                        View
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 rounded-lg gap-1.5"
                      >
                        <Download className="h-4 w-4" />
                        PDF
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 w-8 p-0 rounded-lg"
                        onClick={() => handleWhatsAppShare(test)}
                      >
                        <MessageCircle className="h-4 w-4 text-success" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Payment History */}
          {activeTab === 'payments' && (
            <div className="space-y-3">
              {mockPaymentHistory.map((payment, index) => (
                <div
                  key={payment.id}
                  className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm animate-slide-up"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-success/10 flex items-center justify-center">
                        <Receipt className="h-5 w-5 text-success" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">{payment.invoiceNumber}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>{formatDate(payment.date)}</span>
                          <span className="text-muted-foreground/50">|</span>
                          <span>{payment.method}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-success">Rs.{payment.amount.toLocaleString()}</p>
                      <Badge className="rounded-full text-[10px] bg-success/10 text-success border-0">
                        {payment.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}

              {/* Payment Summary */}
              <div className="bg-gradient-to-r from-primary/5 to-primary/10 border border-primary/20 rounded-2xl p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3">Payment Summary</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Total Paid</span>
                    <span className="font-semibold text-success">Rs.{mockPaymentHistory.reduce((sum, p) => sum + p.amount, 0).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Transactions</span>
                    <span className="font-semibold">{mockPaymentHistory.length}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Pending</span>
                    <span className="font-semibold text-muted-foreground">Rs.0</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Report Preview Modal */}
        {showReportModal && selectedReport && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center animate-fade-in">
            <div className="bg-card w-full max-w-md rounded-t-3xl max-h-[85vh] overflow-hidden animate-slide-up">
              <div className="sticky top-0 bg-card border-b border-border/50 p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Test Report</h3>
                    <p className="text-xs text-muted-foreground">{formatDate(selectedReport.date)}</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="rounded-full h-8 w-8"
                  onClick={() => setShowReportModal(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="overflow-y-auto p-4 space-y-4">
                {/* Patient Info */}
                <div className="bg-muted/30 rounded-xl p-3">
                  <p className="text-xs text-muted-foreground mb-1">Patient</p>
                  <p className="text-sm font-semibold">{selectedPatient.name}</p>
                  <p className="text-xs text-muted-foreground">{selectedPatient.uhid}</p>
                </div>

                {/* Tests */}
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-foreground">Tests Performed</h4>
                  {selectedReport.tests.map((test, i) => (
                    <div key={i} className="bg-card border border-border/50 rounded-xl p-3">
                      <p className="text-sm font-medium text-foreground">{test}</p>
                      <p className="text-xs text-muted-foreground mt-1">Result: Normal</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="sticky bottom-0 bg-card border-t border-border/50 p-4 flex gap-3">
                <Button variant="outline" className="flex-1 rounded-xl h-11 gap-2">
                  <Printer className="h-4 w-4" />
                  Print
                </Button>
                <Button variant="outline" className="flex-1 rounded-xl h-11 gap-2">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
                <Button className="flex-1 rounded-xl h-11 gap-2 bg-success hover:bg-success/90">
                  <MessageCircle className="h-4 w-4" />
                  Share
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Header with Back Button */}
      {onBack && (
        <div className="flex items-center gap-3 mb-2">
          <Button variant="ghost" size="icon" onClick={onBack} className="h-9 w-9 rounded-xl">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-base font-semibold">Patient History</h1>
            <p className="text-xs text-muted-foreground">Search and view patient records</p>
          </div>
        </div>
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name, UHID, or phone..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 pr-10 rounded-xl h-12 bg-card border-border/50"
        />
        <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-9 w-9 rounded-lg">
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <User className="h-4 w-4 text-primary" />
            <span className="text-xs text-primary font-medium">Total Patients</span>
          </div>
          <p className="text-2xl font-bold text-primary">{mockPatients.length}</p>
        </div>
        <div className="bg-success/10 border border-success/20 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <IndianRupee className="h-4 w-4 text-success" />
            <span className="text-xs text-success font-medium">Total Revenue</span>
          </div>
          <p className="text-2xl font-bold text-success">
            Rs.{(mockPatients.reduce((sum, p) => sum + p.totalSpent, 0) / 1000).toFixed(0)}K
          </p>
        </div>
      </div>

      {/* Patients List */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-foreground">Recent Patients</h3>
        {filteredPatients.map((patient, index) => (
          <button
            key={patient.id}
            onClick={() => setSelectedPatient(patient)}
            className="w-full bg-card rounded-2xl border border-border/50 p-4 shadow-sm animate-slide-up text-left hover:border-primary/30 transition-colors"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                  {patient.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">{patient.name}</p>
                <p className="text-xs text-muted-foreground">{patient.uhid} | {patient.gender}, {patient.age}y</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                    <TestTube className="h-3 w-3" />
                    {patient.totalVisits} visits
                  </span>
                  <span className="text-[10px] text-success flex items-center gap-1">
                    <IndianRupee className="h-3 w-3" />
                    Rs.{patient.totalSpent.toLocaleString()}
                  </span>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </div>
          </button>
        ))}
      </div>

      {filteredPatients.length === 0 && (
        <div className="text-center py-12">
          <div className="h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
            <User className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-semibold text-foreground mb-1">No patients found</h3>
          <p className="text-xs text-muted-foreground">Try a different search term</p>
        </div>
      )}
    </div>
  )
}
