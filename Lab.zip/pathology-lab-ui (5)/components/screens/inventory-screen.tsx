'use client'

import { useState } from 'react'
import { 
  Search, 
  Plus, 
  Package,
  AlertTriangle,
  Clock,
  MoreVertical,
  Edit,
  Trash2,
  ShoppingCart,
  TrendingDown
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { mockInventory } from '@/lib/mock-data'
import { cn } from '@/lib/utils'
import { format, differenceInDays } from 'date-fns'

const categoryTabs = ['All', 'Reagents', 'Tubes', 'Consumables', 'Kits']

export function InventoryScreen() {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')

  const filteredItems = mockInventory.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = activeCategory === 'All' || item.category.includes(activeCategory)
    return matchesSearch && matchesCategory
  })

  const lowStockItems = mockInventory.filter((item) => item.quantity <= item.minStock)
  const expiringItems = mockInventory.filter((item) => differenceInDays(item.expiryDate, new Date()) <= 30)

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Alert Cards */}
      {(lowStockItems.length > 0 || expiringItems.length > 0) && (
        <div className="grid grid-cols-2 gap-3">
          {lowStockItems.length > 0 && (
            <div className="bg-critical/10 border border-critical/20 rounded-2xl p-3 flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-critical/20 flex items-center justify-center shrink-0">
                <TrendingDown className="h-5 w-5 text-critical" />
              </div>
              <div>
                <p className="text-xs font-semibold text-critical">Low Stock</p>
                <p className="text-lg font-bold text-critical">{lowStockItems.length}</p>
              </div>
            </div>
          )}
          {expiringItems.length > 0 && (
            <div className="bg-warning/10 border border-warning/20 rounded-2xl p-3 flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-warning/20 flex items-center justify-center shrink-0">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-xs font-semibold text-warning">Expiring Soon</p>
                <p className="text-lg font-bold text-warning">{expiringItems.length}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Search & Add */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search inventory..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 rounded-xl h-11 bg-card"
          />
        </div>
        <Button className="h-11 w-11 rounded-xl shrink-0" size="icon">
          <Plus className="h-5 w-5" />
        </Button>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 custom-scrollbar">
        {categoryTabs.map((tab) => (
          <Button
            key={tab}
            variant={activeCategory === tab ? 'default' : 'outline'}
            size="sm"
            className="rounded-full shrink-0 h-8"
            onClick={() => setActiveCategory(tab)}
          >
            {tab}
          </Button>
        ))}
      </div>

      {/* Inventory List */}
      <div className="space-y-3">
        {filteredItems.map((item, index) => {
          const stockPercentage = (item.quantity / (item.minStock * 5)) * 100
          const isLowStock = item.quantity <= item.minStock
          const daysToExpiry = differenceInDays(item.expiryDate, new Date())
          const isExpiringSoon = daysToExpiry <= 30

          return (
            <div
              key={item.id}
              className={cn(
                "bg-card rounded-2xl border p-4 shadow-sm animate-slide-up",
                isLowStock ? "border-critical/30" : isExpiringSoon ? "border-warning/30" : "border-border/50"
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "h-10 w-10 rounded-xl flex items-center justify-center",
                    isLowStock ? "bg-critical/10" : "bg-primary/10"
                  )}>
                    <Package className={cn(
                      "h-5 w-5",
                      isLowStock ? "text-critical" : "text-primary"
                    )} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{item.category}</p>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 rounded-xl">
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" /> Edit Item
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <ShoppingCart className="mr-2 h-4 w-4" /> Reorder
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-critical">
                      <Trash2 className="mr-2 h-4 w-4" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Stock Level */}
              <div className="space-y-2 mb-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Stock Level</span>
                  <span className={cn(
                    "font-semibold",
                    isLowStock ? "text-critical" : "text-foreground"
                  )}>
                    {item.quantity} {item.unit}
                  </span>
                </div>
                <Progress 
                  value={Math.min(stockPercentage, 100)} 
                  className={cn("h-1.5", isLowStock && "[&>div]:bg-critical")}
                />
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span>Min: {item.minStock} {item.unit}</span>
                  <span>Supplier: {item.supplier}</span>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-border/50">
                <div className="flex items-center gap-2">
                  {isLowStock && (
                    <Badge className="rounded-full text-[10px] bg-critical/10 text-critical" variant="outline">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Low Stock
                    </Badge>
                  )}
                  {isExpiringSoon && (
                    <Badge className="rounded-full text-[10px] bg-warning/10 text-warning" variant="outline">
                      <Clock className="h-3 w-3 mr-1" />
                      Expires {format(item.expiryDate, 'MMM d')}
                    </Badge>
                  )}
                  {!isLowStock && !isExpiringSoon && (
                    <Badge variant="outline" className="rounded-full text-[10px]">
                      In Stock
                    </Badge>
                  )}
                </div>
                <span className="text-[10px] text-muted-foreground">
                  Last restocked: {format(item.lastRestocked, 'MMM d, yyyy')}
                </span>
              </div>

              {/* Reorder Button */}
              {isLowStock && (
                <Button className="w-full mt-3 rounded-xl h-9" size="sm">
                  <ShoppingCart className="h-3.5 w-3.5 mr-1.5" />
                  Reorder Now
                </Button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
