'use client'

import { useState } from 'react'
import { 
  Search, 
  Plus, 
  Phone, 
  Mail,
  MessageCircle,
  MoreVertical,
  Edit,
  Trash2,
  IndianRupee,
  TrendingUp,
  Users,
  Building2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { mockDoctors } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

export function DoctorsScreen() {
  const [searchQuery, setSearchQuery] = useState('')

  const filteredDoctors = mockDoctors.filter((doctor) =>
    doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doctor.specialization.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const totalReferrals = mockDoctors.reduce((sum, d) => sum + d.totalReferrals, 0)
  const totalRevenue = mockDoctors.reduce((sum, d) => sum + d.totalRevenue, 0)

  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users className="h-4 w-4 text-primary" />
            <span className="text-xs text-primary font-medium">Total Referrals</span>
          </div>
          <p className="text-xl font-bold text-primary">{totalReferrals.toLocaleString()}</p>
        </div>
        <div className="bg-success/10 border border-success/20 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <IndianRupee className="h-4 w-4 text-success" />
            <span className="text-xs text-success font-medium">Total Revenue</span>
          </div>
          <p className="text-xl font-bold text-success">Rs. {(totalRevenue / 1000).toFixed(0)}K</p>
        </div>
      </div>

      {/* Search & Add */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search doctors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 rounded-xl h-11 bg-card"
          />
        </div>
        <Button className="h-11 w-11 rounded-xl shrink-0" size="icon">
          <Plus className="h-5 w-5" />
        </Button>
      </div>

      {/* Doctors List */}
      <div className="space-y-3">
        {filteredDoctors.map((doctor, index) => {
          const maxReferrals = Math.max(...mockDoctors.map((d) => d.totalReferrals))
          
          return (
            <div
              key={doctor.id}
              className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {doctor.name.split(' ').slice(1).map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{doctor.name}</p>
                    <p className="text-xs text-muted-foreground">{doctor.specialization}</p>
                    {doctor.hospital && (
                      <div className="flex items-center gap-1 mt-1 text-[10px] text-muted-foreground">
                        <Building2 className="h-3 w-3" />
                        <span>{doctor.hospital}</span>
                      </div>
                    )}
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 rounded-xl">
                    <DropdownMenuItem>
                      <Edit className="mr-2 h-4 w-4" /> Edit Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <IndianRupee className="mr-2 h-4 w-4" /> Settlement
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-critical">
                      <Trash2 className="mr-2 h-4 w-4" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Stats */}
              <div className="space-y-2 mb-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Referrals</span>
                  <span className="font-semibold">{doctor.totalReferrals}</span>
                </div>
                <Progress value={(doctor.totalReferrals / maxReferrals) * 100} className="h-1.5" />
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-3 border-t border-border/50">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="rounded-full text-[10px] bg-primary/5">
                    {doctor.commission}% Commission
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-success">
                    <TrendingUp className="h-3 w-3" />
                    <span className="font-semibold">Rs. {(doctor.totalRevenue / 1000).toFixed(0)}K</span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                    <MessageCircle className="h-4 w-4 text-success" />
                  </Button>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
