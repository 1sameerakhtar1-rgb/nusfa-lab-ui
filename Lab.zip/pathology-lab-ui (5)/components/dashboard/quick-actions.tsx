'use client'

import { 
  Plus, 
  UserPlus, 
  FileText, 
  Receipt, 
  Truck, 
  Beaker,
  QrCode,
  FileSearch
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface QuickAction {
  id: string
  label: string
  icon: React.ElementType
  color: string
  bgColor: string
}

const quickActions: QuickAction[] = [
  { id: 'new-sample', label: 'New Sample', icon: Plus, color: 'text-primary', bgColor: 'bg-primary/10' },
  { id: 'add-patient', label: 'Add Patient', icon: UserPlus, color: 'text-success', bgColor: 'bg-success/10' },
  { id: 'pending-reports', label: 'Pending', icon: FileText, color: 'text-warning', bgColor: 'bg-warning/10' },
  { id: 'new-invoice', label: 'Invoice', icon: Receipt, color: 'text-info', bgColor: 'bg-info/10' },
  { id: 'home-collection', label: 'Collection', icon: Truck, color: 'text-chart-4', bgColor: 'bg-chart-4/10' },
  { id: 'test-entry', label: 'Test Entry', icon: Beaker, color: 'text-chart-5', bgColor: 'bg-chart-5/10' },
  { id: 'scan-qr', label: 'Scan QR', icon: QrCode, color: 'text-muted-foreground', bgColor: 'bg-muted' },
  { id: 'search', label: 'Search', icon: FileSearch, color: 'text-foreground', bgColor: 'bg-secondary' },
]

interface QuickActionsProps {
  onAction: (actionId: string) => void
}

export function QuickActions({ onAction }: QuickActionsProps) {
  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold text-foreground px-1">Quick Actions</h3>
      <div className="grid grid-cols-4 gap-3">
        {quickActions.map((action) => {
          const Icon = action.icon
          return (
            <button
              key={action.id}
              onClick={() => onAction(action.id)}
              className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-card border border-border/50 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            >
              <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", action.bgColor)}>
                <Icon className={cn("h-5 w-5", action.color)} />
              </div>
              <span className="text-[10px] font-medium text-muted-foreground text-center leading-tight">
                {action.label}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
