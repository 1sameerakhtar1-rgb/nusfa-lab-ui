'use client'

import { MapPin, TrendingUp, Users } from 'lucide-react'
import { mockCollectionCenters } from '@/lib/mock-data'
import { cn } from '@/lib/utils'

export function CollectionCenters() {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-semibold text-foreground">Collection Centers</h3>
        <button className="text-xs font-medium text-primary hover:underline">Manage</button>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        {mockCollectionCenters.slice(0, 4).map((center) => (
          <div
            key={center.id}
            className="bg-card rounded-2xl border border-border/50 p-3 shadow-sm space-y-2"
          >
            <div className="flex items-start justify-between">
              <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <MapPin className="h-4 w-4 text-primary" />
              </div>
              <span className={cn(
                "px-2 py-0.5 rounded-full text-[10px] font-semibold",
                center.performance >= 90 
                  ? "bg-success/10 text-success" 
                  : center.performance >= 80 
                    ? "bg-warning/10 text-warning"
                    : "bg-critical/10 text-critical"
              )}>
                {center.performance}%
              </span>
            </div>
            
            <div>
              <p className="text-xs font-semibold text-foreground line-clamp-1">{center.name}</p>
              <p className="text-[10px] text-muted-foreground line-clamp-1">{center.address}</p>
            </div>
            
            <div className="flex items-center justify-between pt-2 border-t border-border/50">
              <div className="flex items-center gap-1">
                <Users className="h-3 w-3 text-muted-foreground" />
                <span className="text-[10px] font-medium text-foreground">
                  {center.totalCollections}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp className="h-3 w-3 text-success" />
                <span className="text-[10px] font-semibold text-success">
                  Rs. {(center.revenue / 1000).toFixed(0)}K
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
