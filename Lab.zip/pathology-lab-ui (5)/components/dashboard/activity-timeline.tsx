'use client'

import { 
  TestTube2, 
  FileCheck, 
  CreditCard, 
  Truck, 
  Beaker,
  UserPlus 
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Activity } from '@/lib/types'
import { formatDistanceToNow } from 'date-fns'

interface ActivityTimelineProps {
  activities: Activity[]
}

const actionIcons: Record<string, { icon: React.ElementType; color: string; bg: string }> = {
  'Sample Created': { icon: TestTube2, color: 'text-primary', bg: 'bg-primary/10' },
  'Report Approved': { icon: FileCheck, color: 'text-success', bg: 'bg-success/10' },
  'Payment Collected': { icon: CreditCard, color: 'text-info', bg: 'bg-info/10' },
  'Home Collection': { icon: Truck, color: 'text-warning', bg: 'bg-warning/10' },
  'Test Completed': { icon: Beaker, color: 'text-chart-4', bg: 'bg-chart-4/10' },
  'Doctor Added': { icon: UserPlus, color: 'text-chart-5', bg: 'bg-chart-5/10' },
}

export function ActivityTimeline({ activities }: ActivityTimelineProps) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-semibold text-foreground">Recent Activity</h3>
        <button className="text-xs font-medium text-primary hover:underline">View All</button>
      </div>
      
      <div className="space-y-3">
        {activities.slice(0, 5).map((activity, index) => {
          const actionConfig = actionIcons[activity.action] || {
            icon: TestTube2,
            color: 'text-muted-foreground',
            bg: 'bg-muted',
          }
          const Icon = actionConfig.icon
          
          return (
            <div
              key={activity.id}
              className="flex items-start gap-3 p-3 rounded-xl bg-card border border-border/50 shadow-sm animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className={cn("h-9 w-9 rounded-lg flex items-center justify-center shrink-0", actionConfig.bg)}>
                <Icon className={cn("h-4 w-4", actionConfig.color)} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">{activity.action}</p>
                <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
                  {activity.description}
                </p>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-[10px] text-muted-foreground">
                    {activity.user}
                  </span>
                  <span className="text-[10px] text-muted-foreground/50">•</span>
                  <span className="text-[10px] text-muted-foreground">
                    {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                  </span>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
