'use client'

import { TrendingUp } from 'lucide-react'
import { popularTests } from '@/lib/mock-data'
import { Progress } from '@/components/ui/progress'

export function PopularTests() {
  const maxCount = Math.max(...popularTests.map((t) => t.count))

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-semibold text-foreground">Popular Tests</h3>
        <button className="text-xs font-medium text-primary hover:underline">View All</button>
      </div>
      
      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm space-y-4">
        {popularTests.map((test, index) => (
          <div key={test.name} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-muted-foreground w-4">
                  {String(index + 1).padStart(2, '0')}
                </span>
                <span className="text-sm font-medium text-foreground">{test.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-3 w-3 text-success" />
                <span className="text-xs font-semibold text-foreground">{test.count}</span>
              </div>
            </div>
            <Progress 
              value={(test.count / maxCount) * 100} 
              className="h-1.5" 
            />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>Revenue: Rs. {test.revenue.toLocaleString()}</span>
              <span>{((test.count / maxCount) * 100).toFixed(0)}% of max</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
