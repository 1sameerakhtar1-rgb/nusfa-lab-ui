'use client'

import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'
import { mockDoctors } from '@/lib/mock-data'
import { TrendingUp, Phone, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function DoctorAnalytics() {
  const maxReferrals = Math.max(...mockDoctors.map((d) => d.totalReferrals))

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-semibold text-foreground">Top Referral Doctors</h3>
        <button className="text-xs font-medium text-primary hover:underline">View All</button>
      </div>
      
      <div className="bg-card rounded-2xl border border-border/50 shadow-sm divide-y divide-border/50">
        {mockDoctors.slice(0, 4).map((doctor, index) => (
          <div key={doctor.id} className="p-3 flex items-center gap-3">
            <div className="relative">
              <Avatar className="h-10 w-10">
                <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                  {doctor.name.split(' ').slice(1).map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <span className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-card border-2 border-card flex items-center justify-center text-[10px] font-bold text-muted-foreground">
                {index + 1}
              </span>
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{doctor.name}</p>
              <p className="text-[10px] text-muted-foreground">{doctor.specialization}</p>
              <div className="mt-1.5 flex items-center gap-2">
                <Progress 
                  value={(doctor.totalReferrals / maxReferrals) * 100} 
                  className="h-1 flex-1" 
                />
                <span className="text-[10px] font-semibold text-foreground">
                  {doctor.totalReferrals}
                </span>
              </div>
            </div>
            
            <div className="flex flex-col items-end gap-1">
              <span className="text-xs font-semibold text-success flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                Rs. {(doctor.totalRevenue / 1000).toFixed(0)}K
              </span>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-6 w-6 rounded-lg">
                  <Phone className="h-3 w-3 text-muted-foreground" />
                </Button>
                <Button variant="ghost" size="icon" className="h-6 w-6 rounded-lg">
                  <MessageCircle className="h-3 w-3 text-success" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
