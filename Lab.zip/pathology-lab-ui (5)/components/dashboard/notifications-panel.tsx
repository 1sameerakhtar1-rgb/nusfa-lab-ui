'use client'

import { Bell, AlertTriangle, CheckCircle, Info, AlertCircle, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Notification } from '@/lib/types'
import { formatDistanceToNow } from 'date-fns'
import { Button } from '@/components/ui/button'

interface NotificationsPanelProps {
  notifications: Notification[]
  onDismiss?: (id: string) => void
  onMarkAllRead?: () => void
}

const notificationIcons = {
  critical: { icon: AlertTriangle, color: 'text-critical', bg: 'bg-critical/10' },
  warning: { icon: AlertCircle, color: 'text-warning', bg: 'bg-warning/10' },
  success: { icon: CheckCircle, color: 'text-success', bg: 'bg-success/10' },
  info: { icon: Info, color: 'text-info', bg: 'bg-info/10' },
}

export function NotificationsPanel({ notifications, onDismiss, onMarkAllRead }: NotificationsPanelProps) {
  const unreadCount = notifications.filter((n) => !n.isRead).length

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold text-foreground">Notifications</h3>
          {unreadCount > 0 && (
            <span className="px-1.5 py-0.5 bg-critical text-critical-foreground text-[10px] font-bold rounded-full">
              {unreadCount}
            </span>
          )}
        </div>
        {unreadCount > 0 && (
          <button 
            onClick={onMarkAllRead}
            className="text-xs font-medium text-primary hover:underline"
          >
            Mark all read
          </button>
        )}
      </div>
      
      <div className="space-y-2">
        {notifications.slice(0, 4).map((notification) => {
          const config = notificationIcons[notification.type]
          const Icon = config.icon
          
          return (
            <div
              key={notification.id}
              className={cn(
                "relative flex items-start gap-3 p-3 rounded-xl border shadow-sm transition-all duration-200",
                notification.isRead 
                  ? "bg-card border-border/50 opacity-70" 
                  : "bg-card border-primary/20"
              )}
            >
              {!notification.isRead && (
                <div className="absolute top-3 left-3 w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              )}
              <div className={cn("h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ml-2", config.bg)}>
                <Icon className={cn("h-4 w-4", config.color)} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">{notification.title}</p>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                  {notification.message}
                </p>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {formatDistanceToNow(notification.createdAt, { addSuffix: true })}
                </p>
              </div>
              {onDismiss && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 rounded-lg shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => onDismiss(notification.id)}
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
