'use client'

import { useState, useEffect, useRef } from 'react'
import { 
  Search, 
  X, 
  User, 
  TestTube2, 
  FileText, 
  Receipt,
  Clock,
  ArrowRight
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

interface SearchResult {
  id: string
  type: 'patient' | 'sample' | 'report' | 'invoice'
  title: string
  subtitle: string
  status?: string
}

const mockSearchResults: SearchResult[] = [
  { id: '1', type: 'patient', title: 'Rahul Kumar', subtitle: 'UHID00001234 • +91 98765 43210' },
  { id: '2', type: 'sample', title: 'SMP2024001', subtitle: 'Rahul Kumar • CBC, Lipid Profile', status: 'Processing' },
  { id: '3', type: 'report', title: 'RPT2024001', subtitle: 'Complete Blood Count • Rahul Kumar', status: 'Ready' },
  { id: '4', type: 'invoice', title: 'INV2024001', subtitle: 'Rs. 1,062 • Paid', status: 'Paid' },
  { id: '5', type: 'patient', title: 'Priya Singh', subtitle: 'UHID00001235 • +91 98765 43211' },
  { id: '6', type: 'sample', title: 'SMP2024002', subtitle: 'Priya Singh • Thyroid Profile', status: 'Pending' },
]

const typeIcons = {
  patient: User,
  sample: TestTube2,
  report: FileText,
  invoice: Receipt,
}

const typeColors = {
  patient: 'bg-primary/10 text-primary',
  sample: 'bg-info/10 text-info',
  report: 'bg-success/10 text-success',
  invoice: 'bg-warning/10 text-warning',
}

interface SearchOverlayProps {
  isOpen: boolean
  onClose: () => void
  onSelect?: (result: SearchResult) => void
}

export function SearchOverlay({ isOpen, onClose, onSelect }: SearchOverlayProps) {
  const [query, setQuery] = useState('')
  const [recentSearches] = useState(['Rahul Kumar', 'CBC', 'INV2024001'])
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus()
    }
  }, [isOpen])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleEscape)
    return () => window.removeEventListener('keydown', handleEscape)
  }, [onClose])

  const filteredResults = query
    ? mockSearchResults.filter(
        (r) =>
          r.title.toLowerCase().includes(query.toLowerCase()) ||
          r.subtitle.toLowerCase().includes(query.toLowerCase())
      )
    : []

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 animate-fade-in">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Search Panel */}
      <div className="relative mx-auto max-w-lg pt-20 px-4">
        <div className="bg-card rounded-2xl border border-border shadow-xl overflow-hidden animate-slide-up">
          {/* Search Input */}
          <div className="relative border-b border-border">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              ref={inputRef}
              placeholder="Search patients, samples, reports..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="border-0 h-14 pl-12 pr-12 text-base rounded-none focus-visible:ring-0"
            />
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg"
              onClick={onClose}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="max-h-[60vh] overflow-y-auto custom-scrollbar">
            {/* Recent Searches */}
            {!query && (
              <div className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Recent Searches</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((search) => (
                    <Button
                      key={search}
                      variant="secondary"
                      size="sm"
                      className="rounded-full h-8"
                      onClick={() => setQuery(search)}
                    >
                      {search}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Search Results */}
            {query && filteredResults.length > 0 && (
              <div className="p-2">
                {filteredResults.map((result) => {
                  const Icon = typeIcons[result.type]
                  return (
                    <button
                      key={result.id}
                      onClick={() => onSelect?.(result)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted/50 transition-colors"
                    >
                      <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", typeColors[result.type])}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-medium text-foreground">{result.title}</p>
                        <p className="text-xs text-muted-foreground">{result.subtitle}</p>
                      </div>
                      {result.status && (
                        <Badge variant="outline" className="rounded-full text-[10px]">
                          {result.status}
                        </Badge>
                      )}
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </button>
                  )
                })}
              </div>
            )}

            {/* No Results */}
            {query && filteredResults.length === 0 && (
              <div className="p-8 text-center">
                <Search className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No results found for &quot;{query}&quot;</p>
                <p className="text-xs text-muted-foreground mt-1">Try searching with different keywords</p>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="p-4 border-t border-border bg-muted/30">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Press <kbd className="px-1.5 py-0.5 bg-muted rounded text-[10px] font-mono">ESC</kbd> to close</span>
              <span>Search everywhere</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
