'use client'

import { Skeleton } from '@/components/ui/skeleton'

export function DashboardSkeleton() {
  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Welcome Banner Skeleton */}
      <Skeleton className="h-28 rounded-2xl" />

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>

      {/* Quick Actions */}
      <div className="space-y-3">
        <Skeleton className="h-5 w-28" />
        <div className="grid grid-cols-4 gap-3">
          {[...Array(8)].map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-2xl" />
          ))}
        </div>
      </div>

      {/* Chart */}
      <Skeleton className="h-52 rounded-2xl" />

      {/* Activity */}
      <div className="space-y-3">
        <Skeleton className="h-5 w-32" />
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-20 rounded-xl" />
        ))}
      </div>
    </div>
  )
}

export function SamplesSkeleton() {
  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Search */}
      <Skeleton className="h-11 rounded-xl" />
      
      {/* Filters */}
      <div className="flex gap-2">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-8 w-20 rounded-full" />
        ))}
      </div>

      {/* List */}
      <div className="space-y-3">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-36 rounded-2xl" />
        ))}
      </div>
    </div>
  )
}

export function ReportsSkeleton() {
  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Alert */}
      <Skeleton className="h-16 rounded-2xl" />
      
      {/* Search */}
      <Skeleton className="h-11 rounded-xl" />
      
      {/* Filters */}
      <div className="flex gap-2">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-8 w-20 rounded-full" />
        ))}
      </div>

      {/* List */}
      <div className="space-y-3">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-44 rounded-2xl" />
        ))}
      </div>
    </div>
  )
}

export function BillingSkeleton() {
  return (
    <div className="space-y-4 pb-6 animate-fade-in">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-3">
        <Skeleton className="h-24 rounded-2xl" />
        <Skeleton className="h-24 rounded-2xl" />
      </div>
      
      {/* Search */}
      <Skeleton className="h-11 rounded-xl" />
      
      {/* Filters */}
      <div className="flex gap-2">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-8 w-20 rounded-full" />
        ))}
      </div>

      {/* List */}
      <div className="space-y-3">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-52 rounded-2xl" />
        ))}
      </div>
    </div>
  )
}

export function AnalyticsSkeleton() {
  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Time Filter */}
      <div className="flex gap-2">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-8 w-16 rounded-full" />
        ))}
      </div>

      {/* Revenue Card */}
      <Skeleton className="h-40 rounded-2xl" />

      {/* Chart */}
      <Skeleton className="h-56 rounded-2xl" />

      {/* Categories */}
      <Skeleton className="h-48 rounded-2xl" />

      {/* Doctors */}
      <Skeleton className="h-44 rounded-2xl" />
    </div>
  )
}

export function MoreSkeleton() {
  return (
    <div className="space-y-6 pb-6 animate-fade-in">
      {/* Profile */}
      <Skeleton className="h-24 rounded-2xl" />

      {/* Quick Settings */}
      <Skeleton className="h-48 rounded-2xl" />

      {/* Sections */}
      {[...Array(3)].map((_, i) => (
        <div key={i} className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-48 rounded-2xl" />
        </div>
      ))}
    </div>
  )
}
