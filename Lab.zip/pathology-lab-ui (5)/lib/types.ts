export type PatientTitle = 'Mr.' | 'Mrs.' | 'Ms.' | 'Md.' | 'Baby' | 'Master'

export type Gender = 'Male' | 'Female' | 'Other'

export type PaymentMethod = 'Cash' | 'Card' | 'UPI' | 'Net Banking' | 'Cheque'

export type SampleStatus = 'Pending' | 'Collected' | 'Processing' | 'Completed' | 'Approved' | 'Delivered'

export type ReportStatus = 'Pending' | 'Processing' | 'Ready' | 'Approved' | 'Delivered' | 'Critical'

export type StaffRole = 'Admin' | 'Receptionist' | 'Technician' | 'Pathologist' | 'Collection Agent'

export type Priority = 'Normal' | 'Urgent' | 'Emergency'

export interface Patient {
  id: string
  uhid: string
  title: PatientTitle
  name: string
  gender: Gender
  age: number
  dob: Date
  phone: string
  email: string
  address: string
  city: string
  pinCode: string
  createdAt: Date
}

export interface Test {
  id: string
  name: string
  code: string
  category: string
  price: number
  turnaroundTime: string
  description?: string
}

export interface Doctor {
  id: string
  name: string
  specialization: string
  phone: string
  email: string
  commission: number
  hospital?: string
  address?: string
  totalReferrals: number
  totalRevenue: number
}

export interface Sample {
  id: string
  barcode: string
  qrCode: string
  patient: Patient
  tests: Test[]
  doctor?: Doctor
  status: SampleStatus
  priority: Priority
  isHomeCollection: boolean
  collectionAgent?: Staff
  collectedAt?: Date
  totalAmount: number
  discount: number
  couponCode?: string
  paidAmount: number
  dueAmount: number
  paymentMethod: PaymentMethod
  createdAt: Date
}

export interface Report {
  id: string
  sample: Sample
  status: ReportStatus
  results: TestResult[]
  approvedBy?: Staff
  approvedAt?: Date
  digitalSignature?: string
  qrVerification: string
  createdAt: Date
}

export interface TestResult {
  testId: string
  testName: string
  value: string
  unit: string
  normalRange: string
  isAbnormal: boolean
  isCritical: boolean
}

export interface Invoice {
  id: string
  invoiceNumber: string
  sample: Sample
  subtotal: number
  discount: number
  gst: number
  total: number
  paidAmount: number
  dueAmount: number
  paymentMethod: PaymentMethod
  isPaid: boolean
  createdAt: Date
}

export interface Staff {
  id: string
  name: string
  role: StaffRole
  email: string
  phone: string
  isActive: boolean
  permissions: string[]
  lastActive: Date
}

export interface Inventory {
  id: string
  name: string
  category: string
  quantity: number
  unit: string
  minStock: number
  expiryDate: Date
  supplier: string
  lastRestocked: Date
}

export interface Branch {
  id: string
  name: string
  address: string
  phone: string
  isMain: boolean
}

export interface CollectionCenter {
  id: string
  name: string
  address: string
  performance: number
  totalCollections: number
  revenue: number
}

export interface Notification {
  id: string
  title: string
  message: string
  type: 'info' | 'success' | 'warning' | 'critical'
  isRead: boolean
  createdAt: Date
}

export interface Activity {
  id: string
  action: string
  description: string
  user: string
  timestamp: Date
}
