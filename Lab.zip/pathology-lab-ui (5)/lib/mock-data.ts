import { 
  Patient, Test, Doctor, Sample, Report, Invoice, Staff, 
  Inventory, Branch, CollectionCenter, Notification, Activity 
} from './types'

export const mockTests: Test[] = [
  { id: '1', name: 'Complete Blood Count (CBC)', code: 'CBC001', category: 'Hematology', price: 350, turnaroundTime: '4 hours' },
  { id: '2', name: 'Lipid Profile', code: 'LIP001', category: 'Biochemistry', price: 650, turnaroundTime: '6 hours' },
  { id: '3', name: 'Liver Function Test (LFT)', code: 'LFT001', category: 'Biochemistry', price: 750, turnaroundTime: '6 hours' },
  { id: '4', name: 'Kidney Function Test (KFT)', code: 'KFT001', category: 'Biochemistry', price: 800, turnaroundTime: '6 hours' },
  { id: '5', name: 'Thyroid Profile (T3, T4, TSH)', code: 'THY001', category: 'Endocrinology', price: 950, turnaroundTime: '8 hours' },
  { id: '6', name: 'HbA1c (Glycated Hemoglobin)', code: 'HBA001', category: 'Diabetes', price: 450, turnaroundTime: '4 hours' },
  { id: '7', name: 'Vitamin D (25-OH)', code: 'VTD001', category: 'Vitamins', price: 1200, turnaroundTime: '24 hours' },
  { id: '8', name: 'Vitamin B12', code: 'VTB001', category: 'Vitamins', price: 800, turnaroundTime: '24 hours' },
  { id: '9', name: 'Urine Routine & Microscopy', code: 'URM001', category: 'Urology', price: 150, turnaroundTime: '2 hours' },
  { id: '10', name: 'Blood Sugar Fasting', code: 'BSF001', category: 'Diabetes', price: 80, turnaroundTime: '2 hours' },
  { id: '11', name: 'Blood Sugar PP', code: 'BSP001', category: 'Diabetes', price: 80, turnaroundTime: '2 hours' },
  { id: '12', name: 'Electrolytes Panel', code: 'ELP001', category: 'Biochemistry', price: 500, turnaroundTime: '4 hours' },
  { id: '13', name: 'Iron Studies', code: 'IRN001', category: 'Hematology', price: 850, turnaroundTime: '6 hours' },
  { id: '14', name: 'CRP (C-Reactive Protein)', code: 'CRP001', category: 'Immunology', price: 450, turnaroundTime: '4 hours' },
  { id: '15', name: 'ESR (Erythrocyte Sedimentation Rate)', code: 'ESR001', category: 'Hematology', price: 100, turnaroundTime: '2 hours' },
]

export const mockDoctors: Doctor[] = [
  { id: '1', name: 'Dr. Rajesh Sharma', specialization: 'General Medicine', phone: '+91 98765 43210', email: 'rajesh.sharma@hospital.com', commission: 15, hospital: 'City Hospital', totalReferrals: 245, totalRevenue: 125000 },
  { id: '2', name: 'Dr. Priya Patel', specialization: 'Cardiology', phone: '+91 98765 43211', email: 'priya.patel@hospital.com', commission: 12, hospital: 'Heart Care Center', totalReferrals: 189, totalRevenue: 98000 },
  { id: '3', name: 'Dr. Amit Kumar', specialization: 'Endocrinology', phone: '+91 98765 43212', email: 'amit.kumar@hospital.com', commission: 18, hospital: 'Diabetes Clinic', totalReferrals: 156, totalRevenue: 87000 },
  { id: '4', name: 'Dr. Sunita Verma', specialization: 'Nephrology', phone: '+91 98765 43213', email: 'sunita.verma@hospital.com', commission: 14, hospital: 'Kidney Institute', totalReferrals: 134, totalRevenue: 76000 },
  { id: '5', name: 'Dr. Arun Singh', specialization: 'Gastroenterology', phone: '+91 98765 43214', email: 'arun.singh@hospital.com', commission: 16, hospital: 'GI Specialists', totalReferrals: 112, totalRevenue: 65000 },
]

export const mockStaff: Staff[] = [
  { id: '1', name: 'Admin User', role: 'Admin', email: 'admin@pathlab.com', phone: '+91 98765 00001', isActive: true, permissions: ['all'], lastActive: new Date() },
  { id: '2', name: 'Sneha Gupta', role: 'Receptionist', email: 'sneha@pathlab.com', phone: '+91 98765 00002', isActive: true, permissions: ['samples', 'billing'], lastActive: new Date() },
  { id: '3', name: 'Rahul Mehta', role: 'Technician', email: 'rahul@pathlab.com', phone: '+91 98765 00003', isActive: true, permissions: ['samples', 'reports'], lastActive: new Date() },
  { id: '4', name: 'Dr. Meera Shah', role: 'Pathologist', email: 'meera@pathlab.com', phone: '+91 98765 00004', isActive: true, permissions: ['reports', 'approve'], lastActive: new Date() },
  { id: '5', name: 'Vijay Patel', role: 'Collection Agent', email: 'vijay@pathlab.com', phone: '+91 98765 00005', isActive: true, permissions: ['home_collection'], lastActive: new Date() },
]

export const mockBranches: Branch[] = [
  { id: '1', name: 'Main Laboratory', address: '123 Healthcare Street, Medical District', phone: '+91 98765 11111', isMain: true },
  { id: '2', name: 'East Branch', address: '456 East Avenue, Suburb Area', phone: '+91 98765 22222', isMain: false },
  { id: '3', name: 'West Collection Center', address: '789 West Road, Commercial Zone', phone: '+91 98765 33333', isMain: false },
]

export const mockCollectionCenters: CollectionCenter[] = [
  { id: '1', name: 'Central Collection Point', address: 'Main Market Area', performance: 95, totalCollections: 1250, revenue: 425000 },
  { id: '2', name: 'North Zone Center', address: 'North District', performance: 88, totalCollections: 890, revenue: 312000 },
  { id: '3', name: 'South Zone Center', address: 'South District', performance: 92, totalCollections: 1100, revenue: 398000 },
  { id: '4', name: 'Corporate Hub', address: 'Business Park', performance: 97, totalCollections: 650, revenue: 285000 },
]

export const mockInventory: Inventory[] = [
  { id: '1', name: 'EDTA Tubes', category: 'Collection Tubes', quantity: 500, unit: 'pcs', minStock: 100, expiryDate: new Date('2025-12-31'), supplier: 'MedSupply Co', lastRestocked: new Date('2024-01-15') },
  { id: '2', name: 'Plain Tubes', category: 'Collection Tubes', quantity: 450, unit: 'pcs', minStock: 100, expiryDate: new Date('2025-11-30'), supplier: 'MedSupply Co', lastRestocked: new Date('2024-01-15') },
  { id: '3', name: 'Glucose Reagent', category: 'Reagents', quantity: 25, unit: 'liters', minStock: 10, expiryDate: new Date('2024-08-15'), supplier: 'DiagnoReagents', lastRestocked: new Date('2024-02-01') },
  { id: '4', name: 'Lipid Profile Kit', category: 'Test Kits', quantity: 15, unit: 'kits', minStock: 5, expiryDate: new Date('2024-09-30'), supplier: 'BioKits Inc', lastRestocked: new Date('2024-01-20') },
  { id: '5', name: 'Alcohol Swabs', category: 'Consumables', quantity: 2000, unit: 'pcs', minStock: 500, expiryDate: new Date('2026-06-30'), supplier: 'CleanMed', lastRestocked: new Date('2024-02-10') },
  { id: '6', name: 'Syringes 5ml', category: 'Consumables', quantity: 800, unit: 'pcs', minStock: 200, expiryDate: new Date('2026-03-31'), supplier: 'MedSupply Co', lastRestocked: new Date('2024-02-05') },
]

export const mockNotifications: Notification[] = [
  { id: '1', title: 'Critical Report Alert', message: 'Patient John Doe has critical glucose levels (450 mg/dL)', type: 'critical', isRead: false, createdAt: new Date(Date.now() - 300000) },
  { id: '2', title: 'Low Stock Warning', message: 'Glucose Reagent stock is below minimum level', type: 'warning', isRead: false, createdAt: new Date(Date.now() - 900000) },
  { id: '3', title: 'Report Approved', message: '15 reports have been approved by Dr. Meera Shah', type: 'success', isRead: true, createdAt: new Date(Date.now() - 1800000) },
  { id: '4', title: 'New Sample Received', message: '5 new samples from City Hospital received', type: 'info', isRead: true, createdAt: new Date(Date.now() - 3600000) },
  { id: '5', title: 'Payment Received', message: 'Payment of Rs. 15,000 received from Dr. Rajesh Sharma', type: 'success', isRead: true, createdAt: new Date(Date.now() - 7200000) },
]

export const mockActivities: Activity[] = [
  { id: '1', action: 'Sample Created', description: 'New sample #SMP2024001 created for patient Rahul Kumar', user: 'Sneha Gupta', timestamp: new Date(Date.now() - 120000) },
  { id: '2', action: 'Report Approved', description: 'Report #RPT2024045 approved with digital signature', user: 'Dr. Meera Shah', timestamp: new Date(Date.now() - 300000) },
  { id: '3', action: 'Payment Collected', description: 'Cash payment of Rs. 2,500 collected for INV2024089', user: 'Sneha Gupta', timestamp: new Date(Date.now() - 600000) },
  { id: '4', action: 'Home Collection', description: 'Sample collected from 45 Green Park for patient Priya Singh', user: 'Vijay Patel', timestamp: new Date(Date.now() - 900000) },
  { id: '5', action: 'Test Completed', description: 'CBC test completed for sample #SMP2024098', user: 'Rahul Mehta', timestamp: new Date(Date.now() - 1200000) },
  { id: '6', action: 'Doctor Added', description: 'New referral doctor Dr. Ananya Reddy added to system', user: 'Admin User', timestamp: new Date(Date.now() - 1800000) },
]

export const mockDashboardStats = {
  monthlyRevenue: 1245000,
  dailyCollection: 45600,
  pendingReports: 28,
  reportsDelivered: 156,
  totalSamples: 342,
  completedTests: 1250,
  activePatients: 890,
  pendingPayments: 125000,
}

export const revenueChartData = [
  { month: 'Jan', revenue: 980000, collections: 850 },
  { month: 'Feb', revenue: 1050000, collections: 920 },
  { month: 'Mar', revenue: 1120000, collections: 980 },
  { month: 'Apr', revenue: 1080000, collections: 950 },
  { month: 'May', revenue: 1200000, collections: 1050 },
  { month: 'Jun', revenue: 1245000, collections: 1100 },
]

export const testCategoryData = [
  { name: 'Biochemistry', value: 35, count: 450 },
  { name: 'Hematology', value: 25, count: 320 },
  { name: 'Endocrinology', value: 18, count: 230 },
  { name: 'Immunology', value: 12, count: 155 },
  { name: 'Others', value: 10, count: 128 },
]

export const popularTests = [
  { name: 'Complete Blood Count', count: 245, revenue: 85750 },
  { name: 'Lipid Profile', count: 189, revenue: 122850 },
  { name: 'Thyroid Profile', count: 156, revenue: 148200 },
  { name: 'HbA1c', count: 134, revenue: 60300 },
  { name: 'Liver Function Test', count: 112, revenue: 84000 },
]

export const hourlyData = [
  { hour: '8AM', samples: 12 },
  { hour: '9AM', samples: 28 },
  { hour: '10AM', samples: 45 },
  { hour: '11AM', samples: 38 },
  { hour: '12PM', samples: 22 },
  { hour: '1PM', samples: 15 },
  { hour: '2PM', samples: 32 },
  { hour: '3PM', samples: 42 },
  { hour: '4PM', samples: 35 },
  { hour: '5PM', samples: 28 },
  { hour: '6PM', samples: 18 },
]

export const testCategories = [
  'Hematology',
  'Biochemistry', 
  'Endocrinology',
  'Immunology',
  'Microbiology',
  'Serology',
  'Histopathology',
  'Cytology',
  'Vitamins',
  'Diabetes',
  'Urology',
]
